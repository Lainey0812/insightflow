import { fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { it, expect, vi } from 'vitest';
import ReportPage, { ReportDocument } from '../reporting/ReportPage';
import { api } from '../api/client';
import type { AnalysisReport, ReportPresentation } from '../types/report';
import reportFixture from './fixtures/sales-report.json';
import viewFixture from './fixtures/business-sales-report.json';

vi.mock('../reporting/InteractiveChart', () => ({default:({title}:{title:string})=><div role="img" aria-label={title}>真实结果图表</div>}));
const report=reportFixture as unknown as AnalysisReport;
const view=viewFixture as unknown as ReportPresentation;

it('renders the requested narrative order and three scoped KPI cards',()=>{
  render(<ReportDocument report={report} presentation={view}/>);
  expect(screen.getByRole('heading',{level:1})).toHaveTextContent('2026 年华东地区城市销售额 Top 3 分析');
  expect(screen.getAllByRole('heading',{level:2}).map(h=>h.textContent)).toEqual(['执行摘要','核心发现与业务解读','建议进一步分析','数据说明']);
  expect(screen.getByText('已完成订单 · 按城市汇总 · 销售额降序排名')).toBeInTheDocument();
  for(const amount of ['21,250','4.9%','87.8%'])expect(screen.getByText(amount,{exact:true})).toBeVisible();
  expect(screen.getByText('占前三名合计')).toBeVisible();
  expect(screen.getByText(/约为济南的 27.1%/,{selector:'p'})).toBeVisible();
  expect(screen.getByText(/并不是它们在整个地区/)).toBeVisible();
  expect(screen.getByText(/上传数据共 60 条，本任务报告有效样本量为 16 条/)).toBeVisible();
  expect(screen.getByText(/这些补充分析尚未执行/)).toBeVisible();
  expect(screen.queryByRole('heading',{name:'计划内核心任务已有可用结果'})).not.toBeInTheDocument();
  expect(screen.getByRole('link',{name:'下载报告（HTML）'})).toBeVisible();
});

it('reveals evidence and compatible chart/table interactions without generating new analysis',async()=>{
  const create=vi.spyOn(api,'create');const generate=vi.spyOn(api,'generateReport');
  render(<ReportDocument report={report} presentation={view}/>);
  expect(screen.queryByLabelText(`${report.charts[0].title}图表类型`)).not.toBeInTheDocument();
  const card = screen.getByText('占前三名合计').closest('article')!;
  await userEvent.click(within(card).getByText(/查看证据与统计口径/));
  expect(within(card).getByText(/分母仅为前三名合计/)).toBeVisible();
  await userEvent.click(screen.getByText('查看图表与结果数据',{exact:true}));
  const selector=await screen.findByLabelText(`${report.charts[0].title}图表类型`);
  fireEvent.change(selector,{target:{value:'table'}});
  expect(await screen.findByRole('table')).toHaveTextContent('20,250');
  expect(create).not.toHaveBeenCalled();expect(generate).not.toHaveBeenCalled();
});

it('loads persisted report and presentation without a model call and keeps partial status visible',async()=>{
  vi.spyOn(api,'analysisReport').mockResolvedValue({...report,goal_coverage:'partial',report_status:'partial'});
  vi.spyOn(api,'reportPresentation').mockResolvedValue(view);
  render(<ReportPage reportId={report.report_id}/>);
  await screen.findByRole('heading',{name:view.title});
  expect(screen.getByText('报告部分生成')).toBeVisible();
  expect(screen.getByText('目标部分覆盖')).toBeVisible();
});

it('keeps the stored report accessible when presentation loading fails',async()=>{
  vi.spyOn(api,'analysisReport').mockResolvedValue(report);
  vi.spyOn(api,'reportPresentation').mockRejectedValue(new Error('展示暂时不可用'));
  render(<ReportPage reportId={report.report_id}/>);
  expect(await screen.findByRole('heading',{name:report.summary.headline})).toBeInTheDocument();
});

it('renders composed saved insights with E references and does not add legacy rule findings',()=>{
  const unified: ReportPresentation={...view,presentation_version:'business-report-v1.1',kind:'general',
    findings:report.insights.map(i=>({title:i.finding,body:i.implication,evidence_refs:i.evidence_refs})),
    recommendations:report.recommendations.map(r=>r.text),evidence:[]};
  render(<ReportDocument report={report} presentation={unified}/>);
  expect(screen.getAllByRole('heading',{level:3}).filter(h=>h.textContent?.startsWith('发现 '))).toHaveLength(report.insights.length);
  expect(screen.queryByText(/V001 ·/)).not.toBeInTheDocument();
  for(const i of report.insights){
    expect(screen.getByRole('heading',{name:`发现 ${report.insights.indexOf(i)+1}：${i.finding}`})).toBeVisible();
    expect(screen.getByText(i.implication,{exact:true})).toBeVisible();
  }
  for(const r of report.recommendations)expect(screen.getByText(r.text,{exact:true})).toBeVisible();
});

it('retains rejected candidate reasons in collapsed report details',async()=>{
  const withRejection: AnalysisReport={...report,report_status:'partial',execution_metadata:{
    T01:{...report.execution_metadata.T01,insight_generation_version:'evidence-composition-v1.1',
      rejected_insights:[{candidate_index:2,primary_evidence_id:'E0011',error_code:'REPORT_UNVERIFIED_FACT'}]}}};
  render(<ReportDocument report={withRejection} presentation={{...view,presentation_version:'business-report-v1.1'}}/>);
  expect(screen.getByText('报告部分生成')).toBeVisible();
  await userEvent.click(screen.getByText('报告来源与版本',{exact:true}));
  await userEvent.click(screen.getByText('候选洞察校验记录',{exact:true}));
  expect(screen.getByText(/候选 3 · 证据 E0011 · REPORT_UNVERIFIED_FACT/)).toBeVisible();
});
