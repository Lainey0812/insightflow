import { LoaderCircle } from 'lucide-react';
import { statusLabels, type Session } from '../types/contracts';

export function WorkflowProgress({session, busy, onRetry}: {session: Session; busy: boolean; onRetry: () => void}) {
  const active = ['CREATED', 'PROFILING', 'PARSING_INTENT', 'PLANNING', 'VALIDATING', 'RUNNING'].includes(session.status);
  const profile = session.profile && 'row_count' in session.profile ? session.profile : null;
  return <section className="plan-card workflow-progress" aria-label="真实流程状态">
    <h3>{active && <LoaderCircle size={17} className="spin"/>} {statusLabels[session.status]}</h3>
    <p>流程进度已保存，刷新页面可继续查看。{session.status === 'AWAITING_APPROVAL' && '请在下方审核；未批准不会执行。'}</p>
    {profile && <p>数据概况：{profile.row_count} 行 · {profile.column_count} 列 · {profile.quality_issues.length} 项质量提示</p>}
    {session.intent && 'analysis_goal' in session.intent && <p>已理解目标：{session.intent.analysis_goal.business_goal ?? '等待补充明确的分析目标'}</p>}
    {session.status === 'FAILED' && session.error && <><p role="alert">{session.error.message}</p><details><summary>技术详情</summary><p>{session.error.code}</p></details></>}
    {session.status === 'FAILED' && session.error?.retryable && !session.review_plan && !session.engine_execution_ids?.length && <button className="secondary-button" onClick={onRetry} disabled={busy}>重试准备</button>}
    {!!session.workflow_events?.length && <details><summary>查看流程记录</summary><ol>{session.workflow_events.map((event, i) => <li key={i}>{statusLabels[event.status]} · {new Date(event.recorded_at).toLocaleString('zh-CN')}</li>)}</ol></details>}
  </section>;
}
