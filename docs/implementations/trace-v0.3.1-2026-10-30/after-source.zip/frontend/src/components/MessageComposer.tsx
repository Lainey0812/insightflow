import { useRef, type FormEvent, type KeyboardEvent } from 'react';
import { ArrowUp, Compass, FileSpreadsheet, LoaderCircle, Paperclip, Sparkles, X } from 'lucide-react';
import type { AnalysisMode } from '../types/contracts';
import { MockNotice } from './MockNotice';

interface Props {
  text: string; file: File | null; mode: AnalysisMode; busy: boolean; hasSession: boolean; locked: boolean;
  headerRow: string; onHeaderRow: (value: string) => void;
  legacyMockProfile?: boolean;
  realReview?: boolean;
  realWorkflow?: boolean;
  clarifying?: boolean;
  onText: (text: string) => void; onFile: (file: File | null) => void; onMode: (mode: AnalysisMode) => void;
  onSubmit: () => void; onNew: () => void;
}
export function MessageComposer({ text, file, mode, busy, hasSession, locked, headerRow, onHeaderRow, legacyMockProfile, realReview, realWorkflow, clarifying = false, onText, onFile, onMode, onSubmit, onNew }: Props) {
  const input = useRef<HTMLInputElement>(null);
  const validHeader = headerRow.trim() !== '' && Number.isInteger(Number(headerRow)) && Number(headerRow) >= 1 && Number(headerRow) <= 100001;
  const canSend = !busy && !locked && (hasSession ? !!text.trim() : !!file && validHeader && (!!text.trim() || (!realReview && mode === 'exploratory')));
  function submit(event: FormEvent) { event.preventDefault(); if (canSend) onSubmit(); }
  function keyDown(event: KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key === 'Enter' && !event.shiftKey && !event.nativeEvent.isComposing) { event.preventDefault(); if (canSend) onSubmit(); }
  }
  return <div className="composer-area">
    {locked ? <div className="completed-composer"><span>{realWorkflow ? '请查看上方流程状态、审核计划或查看真实计算结果。' : realReview ? '请在上方提交、审核计划或查看真实执行结果。' : '这次探索已结束，开始下一个业务问题吧。'}</span><button className="secondary-button" onClick={onNew} disabled={busy}>新建分析 <ArrowUp size={14} /></button></div> : <form className={`composer ${busy ? 'busy' : ''}`} onSubmit={submit} onDragOver={e => { if (!hasSession && !busy) e.preventDefault(); }} onDrop={e => { e.preventDefault(); if (!hasSession && !busy) onFile(e.dataTransfer.files[0] ?? null); }}>
      {file && !hasSession && <div className="selected-file"><FileSpreadsheet size={19} /><span><strong>{file.name}</strong><small>{(file.size / 1024).toFixed(1)} KB</small></span><button className="icon-button" type="button" aria-label="移除文件" onClick={() => onFile(null)} disabled={busy}><X size={14} /></button></div>}
      {file && !hasSession && <div className="file-settings"><label htmlFor="header-row">表头在第 <input id="header-row" aria-label="表头行" type="number" min={1} max={100001} step={1} value={headerRow} onChange={e => onHeaderRow(e.target.value)} disabled={busy} aria-invalid={!validHeader} aria-describedby="header-row-help" /> 行</label><span id="header-row-help">{validHeader ? '从 1 开始，表头之前的行不参与画像' : '请输入 1–100001 之间的整数'}</span></div>}
      <textarea aria-label={clarifying ? '补充分析需求' : hasSession ? '修改分析计划' : '分析需求'} value={text} onChange={e => onText(e.target.value)} onKeyDown={keyDown} placeholder={clarifying ? '请回答上方问题，补充分析所需的信息…' : hasSession ? '告诉我怎样调整计划，例如：增加地区对比…' : '你想从数据中了解什么？'} maxLength={2000} rows={2} disabled={busy} />
      <div className="composer-toolbar"><div className="composer-options">
        {!hasSession && <><input ref={input} type="file" accept=".csv,.xlsx" hidden aria-label="上传数据文件" onChange={e => { onFile(e.target.files?.[0] ?? null); e.target.value = ''; }} disabled={busy} /><button className="attach-button" type="button" onClick={() => input.current?.click()} disabled={busy}><Paperclip size={17} /><span>上传数据</span></button><span className="toolbar-divider" /><button className={`mode-button ${mode === 'goal_driven' ? 'selected' : ''}`} aria-pressed={mode === 'goal_driven'} type="button" onClick={() => onMode('goal_driven')} disabled={busy}><Sparkles size={13} />目标驱动</button><button className={`mode-button ${mode === 'exploratory' ? 'selected' : ''}`} aria-pressed={mode === 'exploratory'} type="button" onClick={() => onMode('exploratory')} disabled={busy}><Compass size={13} />探索分析</button></>}
        {hasSession && <span className="revision-hint"><Sparkles size={14} />{clarifying ? '补充必要信息后再继续规划' : 'Mock 支持增加地区、趋势、产品、概况任务'}</span>}
      </div><button className="send-button" type="submit" disabled={!canSend} aria-label="发送">{busy ? <LoaderCircle className="spin" size={19} /> : <ArrowUp size={21} />}</button></div>
    </form>}
    <div className="composer-footnote">{!hasSession && !locked && <span>支持 CSV、XLSX · 单文件 ≤ 10 MB</span>}<MockNotice legacyMock={legacyMockProfile} realReview={realReview} realWorkflow={realWorkflow}/></div>
  </div>;
}
