import { ArrowUpRight, ChevronLeft, Database, MessageSquare, Plus, ShieldCheck } from 'lucide-react';
import type { SessionSummary } from '../types/contracts';
import { statusLabels } from '../types/contracts';
import { Brand } from './Brand';

interface Props {
  sessions: SessionSummary[]; selectedId?: string; busy: boolean; open: boolean;
  onSelect: (id: string) => void; onNew: () => void; onClose: () => void;
}
export function SessionSidebar({ sessions, selectedId, busy, open, onSelect, onNew, onClose }: Props) {
  return <>
    {open && <button className="sidebar-scrim" aria-label="关闭会话列表" onClick={onClose} />}
    <aside className={`sidebar ${open ? 'is-open' : ''}`}>
      <div className="brand"><Brand /><span>InsightFlow<span className="brand-dot">.</span></span><button className="icon-button mobile-close" aria-label="收起会话列表" onClick={onClose}><ChevronLeft size={18} /></button></div>
      <button className="new-session" onClick={onNew} disabled={busy}><Plus size={18} />新建分析<span className="new-key">＋</span></button>
      <div className="nav-heading"><span>分析记录</span><span>{String(sessions.length).padStart(2, '0')}</span></div>
      <nav className="session-list" aria-label="历史会话">
        {sessions.length === 0 ? <div className="no-history"><MessageSquare size={21} /><p>还没有分析记录</p><span>你的每一次探索，都会保存在这里</span></div> : sessions.map(session =>
          <button key={session.id} title={session.title} className={`session-item ${session.id === selectedId ? 'active' : ''}`} onClick={() => onSelect(session.id)} disabled={busy} aria-current={session.id === selectedId ? 'page' : undefined}>
            <MessageSquare size={16} /><span><strong>{session.title}</strong><small><i className={`status-dot ${session.status.toLowerCase()}`} />{statusLabels[session.status]}</small></span>
          </button>)}
      </nav>
      <div className="sidebar-bottom"><div className="sandbox-card"><span className="sandbox-icon"><Database size={17} /></span><div><strong>从数据，到洞察</strong><p>让每一个业务判断有据可循</p></div><ArrowUpRight size={15} /></div>
        <div className="local-workspace"><span className="workspace-avatar">IF</span><span><strong>本地工作空间</strong><small><ShieldCheck size={11} /> 数据保存在本机</small></span><span className="phase-tag">MVP</span></div>
      </div>
    </aside>
  </>;
}
