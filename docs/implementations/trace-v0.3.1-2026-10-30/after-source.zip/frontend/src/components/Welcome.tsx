import { ArrowUpRight, ChartNoAxesCombined, Compass, Layers3, Sparkles } from 'lucide-react';

const suggestions = [
  { icon: ChartNoAxesCombined, title: '看清业务趋势', description: '销售变化，哪些值得关注？', prompt: '帮我分析销售额的变化趋势，以及不同产品的销售贡献。' },
  { icon: Layers3, title: '找到关键贡献', description: '哪些产品带来了更多收入？', prompt: '帮我比较不同产品的销售贡献，找出值得关注的产品。' },
  { icon: Compass, title: '探索数据可能', description: '没有明确方向？从这里开始', prompt: '探索这份数据，帮助我发现值得关注的现象。' },
];
export function Welcome({ onSuggestion }: { onSuggestion: (value: string, exploratory: boolean) => void }) {
  return <div className="welcome"><div className="welcome-symbol"><ChartNoAxesCombined size={34} strokeWidth={1.6} /><span><Sparkles size={13} /></span></div>
    <div className="eyebrow">A LITTLE DATA. A NEW PERSPECTIVE.</div>
    <h1>让数据，回答你的<span>业务问题。</span></h1>
    <p className="welcome-description">上传一份表格，聊聊你想了解什么。<br />AI 生成分析计划，你审核后再计算。</p>
    <div className="suggestions">{suggestions.map((item, i) => <button key={item.title} onClick={() => onSuggestion(item.prompt, i === 2)}><span className={`suggestion-icon tone-${i}`}><item.icon size={19} /></span><strong>{item.title}<ArrowUpRight size={14} /></strong><p>{item.description}</p></button>)}</div>
    <div className="welcome-process"><span>01 上传数据</span><i /><span>02 AI 规划与人工审核</span><i /><span>03 查看真实计算</span></div>
  </div>;
}
