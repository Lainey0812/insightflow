import { useEffect, useState } from 'react';
import { AlertCircle, ChevronRight, FlaskConical, LoaderCircle, Menu, RefreshCw, X } from 'lucide-react';
import { api, ApiError } from './api/client';
import type { AnalysisMode, Session, SessionSummary } from './types/contracts';
import { statusLabels } from './types/contracts';
import { SessionSidebar } from './components/SessionSidebar';
import { Welcome } from './components/Welcome';
import { MessageComposer } from './components/MessageComposer';
import { MessageList } from './components/MessageList';
import { PlanImport } from './components/PlanImport';
import { WorkflowProgress } from './components/WorkflowProgress';

const STORAGE_KEY = 'insightflow.session';
export default function App() {
  const [sessions, setSessions] = useState<SessionSummary[]>([]);
  const [session, setSession] = useState<Session | null>(null);
  const [text, setText] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [headerRow, setHeaderRow] = useState('1');
  const [mode, setMode] = useState<AnalysisMode>('goal_driven');
  const [busy, setBusy] = useState(false);
  const [initializing, setInitializing] = useState(true);
  const [pending, setPending] = useState('');
  const [health, setHealth] = useState<'checking' | 'online' | 'offline'>('checking');
  const [error, setError] = useState('');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  async function checkHealth() {
    setHealth('checking');
    try { const result = await api.health(); setHealth(result.status === 'ok' ? 'online' : 'offline'); }
    catch { setHealth('offline'); }
  }
  async function refreshList() { setSessions(await api.list()); }
  function selectSession(next: Session | null) {
    setSession(current => current && next && current.id === next.id && current.revision > next.revision ? current : next);
    if (next) localStorage.setItem(STORAGE_KEY, next.id); else localStorage.removeItem(STORAGE_KEY);
  }
  useEffect(() => {
    let alive = true;
    async function initialize() {
      void checkHealth();
      try {
        const list = await api.list();
        if (!alive) return;
        setSessions(list);
        const id = localStorage.getItem(STORAGE_KEY);
        if (id && list.some(s => s.id === id)) {
          const current = await api.session(id);
          if (alive) setSession(current);
        } else localStorage.removeItem(STORAGE_KEY);
      } catch (err) { if (alive) setError(err instanceof Error ? err.message : '加载失败。'); }
      finally { if (alive) setInitializing(false); }
    }
    void initialize();
    return () => { alive = false; };
  }, []);

  const reportPending = session?.report_generations?.some(r => ['queued', 'generating'].includes(r.status)) ?? false;
  useEffect(() => {
    if (session?.workflow_kind !== 'real_v1' || (!['CREATED', 'PROFILING', 'PARSING_INTENT', 'PLANNING', 'VALIDATING', 'RUNNING'].includes(session.status) && !reportPending)) return;
    let alive = true;
    let polling = false;
    const id = session.id;
    const previous = session.status;
    const timer = window.setInterval(async () => {
      if (polling) return;
      polling = true;
      try {
        const next = await api.session(id);
        if (alive) {
          setSession(current => current?.id === id && current.revision <= next.revision ? next : current);
          if (next.status !== previous) void refreshList().catch(() => {});
        }
      } catch (err) { if (alive) setError(err instanceof Error ? err.message : '读取流程状态失败，请刷新重试。'); }
      finally { polling = false; }
    }, 1000);
    return () => { alive = false; window.clearInterval(timer); };
  }, [session?.id, session?.status, session?.workflow_kind, reportPending]);

  async function perform(label: string, action: () => Promise<Session>, clearDraft = false) {
    if (busy) return;
    setBusy(true); setPending(label); setError('');
    try {
      const next = await action(); selectSession(next);
      if (clearDraft) { setText(''); setFile(null); }
      try { await refreshList(); } catch { setError('会话已保存，但历史列表刷新失败，请稍后刷新页面。'); }
    } catch (err) {
      setError(err instanceof Error ? err.message : '操作失败，请重试。');
      if (session && ((err instanceof ApiError && err.status === 409) || session.review_status)) {
        try { selectSession(await api.session(session.id)); } catch { /* Keep last visible state. */ }
      }
    } finally { setBusy(false); setPending(''); }
  }
  function newSession() { selectSession(null); setText(''); setFile(null); setHeaderRow('1'); setMode('goal_driven'); setError(''); setSidebarOpen(false); }
  function chooseFile(next: File | null) {
    if (next && !/\.(csv|xlsx)$/i.test(next.name)) { setError('请选择 CSV 或 XLSX 文件。'); return; }
    if (next && (next.size === 0 || next.size > 10 * 1024 * 1024)) { setError('文件不能为空，且不能超过 10 MB。'); return; }
    setFile(next); setHeaderRow('1'); setError('');
  }
  function submit() {
    if (session?.status === 'WAITING_FOR_CLARIFICATION') void perform('正在结合补充信息理解分析需求…', () => api.clarify(session, text), true);
    else if (session) void perform('正在生成新的计划版本…', () => api.revise(session, text), true);
    else if (file && Number.isInteger(Number(headerRow)) && Number(headerRow) >= 1 && Number(headerRow) <= 100001)
      void perform('正在计算真实数据画像并理解分析需求…', () => api.create(file, text, mode, Number(headerRow)), true);
  }
  function confirm(warnings: string[] = []) {
    if (!session) return;
    if (session.review_plan) {
      void perform('正在保存审批并执行真实数据…', async () => {
        const approved = session.review_status === 'approved' ? session : await api.approveReal(session, warnings);
        selectSession(approved);
        await api.executeReal(approved);
        return api.session(approved.id);
      });
      return;
    }
    void perform('计划已确认，正在执行示例计算并生成报告…', async () => {
      const approved = session.status === 'APPROVED' ? session : await api.approve(session);
      selectSession(approved);
      return api.execute(approved);
    });
  }
  const realWorkflow = !session || session.workflow_kind === 'real_v1';
  const locked = !!session && !(realWorkflow && session.status === 'WAITING_FOR_CLARIFICATION') && (!!session.review_status || !['WAITING_FOR_CLARIFICATION', 'AWAITING_APPROVAL', 'APPROVED'].includes(session.status));

  return <div className="app-shell">
    <SessionSidebar sessions={sessions} selectedId={session?.id} busy={busy || initializing} open={sidebarOpen} onNew={newSession} onClose={() => setSidebarOpen(false)} onSelect={id => { setSidebarOpen(false); setText(''); setFile(null); void perform('正在恢复会话…', () => api.session(id)); }} />
    <main className="workspace">
      <header className="workspace-header"><div className="breadcrumbs"><button className="icon-button sidebar-toggle" aria-label="打开会话列表" onClick={() => setSidebarOpen(true)}><Menu size={19} /></button><span>工作空间</span><ChevronRight size={13} /><strong>{session?.title ?? '新的分析'}</strong>{session && <span className={`session-status ${session.status.toLowerCase()}`}>{statusLabels[session.status]}</span>}</div><div className="header-tools"><span className="environment"><FlaskConical size={13} /> {realWorkflow ? '真实分析流程' : session && !session.review_status ? '历史 MOCK' : '真实 HITL'}</span><button className={`health-indicator ${health}`} onClick={() => { void checkHealth(); void refreshList().catch(() => setError('会话列表加载失败，请检查后端服务。')); }} title="重新检查后端连接" aria-label={`后端${health === 'online' ? '已连接' : health === 'offline' ? '未连接' : '检查中'}，点击重试`}><i />{health === 'online' ? '服务已连接' : health === 'offline' ? '服务未连接' : '连接中'}{health === 'offline' && <RefreshCw size={12} />}</button></div></header>
      <div className={`conversation ${session ? 'has-session' : ''}`}>
        {initializing ? <div className="initial-loading"><LoaderCircle size={22} className="spin" />正在打开工作空间…</div> : session ? <>{session.workflow_kind === 'real_v1' && <WorkflowProgress session={session} busy={busy} onRetry={() => void perform('正在按保存检查点重试…', () => api.retryPreparation(session))}/>}<MessageList onReportChange={() => void api.session(session.id).then(selectSession)} session={session} busy={busy} pending={pending} onRestart={newSession} onConfirm={confirm} onRemove={id => void perform('正在更新计划版本…', () => api.revise(session, '', [id]))} />{session.workflow_kind !== 'real_v1' && session.review_status && !session.review_plan && <PlanImport key={session.id} session={session} busy={busy} onSave={action => void perform('正在保存并校验真实计划…', action)}/>}</> : <div className="welcome-wrap"><Welcome onSuggestion={(value, exploratory) => { setText(value); setMode(exploratory ? 'exploratory' : 'goal_driven'); }} />{busy && <div className="pending-message" role="status"><LoaderCircle size={17} className="spin" />{pending}</div>}</div>}
      </div>
      <div className="composer-container">{error && <div className="error-banner" role="alert"><AlertCircle size={17} /><span>{error}</span><button className="icon-button" aria-label="关闭提示" onClick={() => setError('')}><X size={14} /></button></div>}<MessageComposer realWorkflow={realWorkflow} realReview={!session || !!session.review_status} text={text} file={file} headerRow={headerRow} onHeaderRow={setHeaderRow} mode={session?.analysis_mode ?? mode} busy={busy || initializing} hasSession={!!session} locked={locked} clarifying={session?.status === 'WAITING_FOR_CLARIFICATION'} legacyMockProfile={session?.profile?.provenance.source === 'mock'} onText={setText} onFile={chooseFile} onMode={setMode} onSubmit={submit} onNew={newSession} /></div>
    </main>
  </div>;
}
