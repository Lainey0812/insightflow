import asyncio
import json

import httpx
import pytest

from app.core.config import Settings
from app.domain.errors import AppError
from app.domain.intent import ParsedIntent
from app.llm.base import LLMRequest
from app.llm.compatible_provider import CompatibleLLMProvider, UnconfiguredLLMProvider
from app.llm.factory import create_provider
from intent_fixtures import intent_payload


def request():
    return LLMRequest(purpose="intent_v1", instruction='{"user_query":"分析数据"}',
                      system_prompt="interpret only", response_schema=ParsedIntent.model_json_schema())


def test_compatible_provider_uses_structured_schema_and_separate_system_data_messages():
    captured = []
    def handler(http_request):
        captured.append(http_request)
        return httpx.Response(200, json={"choices": [{"finish_reason": "stop", "message": {
            "content": json.dumps(intent_payload()), "refusal": None}}]})
    provider = CompatibleLLMProvider("https://llm.example.test/v1", "configured-model", "test-secret", transport=httpx.MockTransport(handler))
    output = asyncio.run(provider.generate(request()))
    assert not output.is_mock and output.model == "configured-model"
    sent = json.loads(captured[0].content)
    assert str(captured[0].url) == "https://llm.example.test/v1/chat/completions"
    assert captured[0].headers["Authorization"] == "Bearer test-secret"
    assert sent["response_format"]["json_schema"]["strict"] is True
    assert sent["response_format"]["json_schema"]["schema"] == ParsedIntent.model_json_schema()
    assert [m["role"] for m in sent["messages"]] == ["system", "user"]
    assert "tools" not in sent


@pytest.mark.parametrize("status,code", [(401, "LLM_HTTP_ERROR"), (429, "LLM_RATE_LIMITED"), (500, "LLM_HTTP_ERROR"), (302, "LLM_HTTP_ERROR")])
def test_upstream_errors_do_not_expose_bodies_or_secrets(status, code):
    provider = CompatibleLLMProvider("https://llm.example.test/v1", "model", "test-secret",
        transport=httpx.MockTransport(lambda req: httpx.Response(status, text="test-secret upstream diagnostics")))
    with pytest.raises(AppError) as error:
        asyncio.run(provider.generate(request()))
    assert error.value.error.code == code
    assert "test-secret" not in error.value.error.message


@pytest.mark.parametrize("body,code", [
    ({"choices": []}, "LLM_INVALID_OUTPUT"),
    ({"choices": [{"finish_reason": "length", "message": {"content": "{}"}}]}, "LLM_INCOMPLETE_OUTPUT"),
    ({"choices": [{"finish_reason": "stop", "message": {"refusal": "no", "content": None}}]}, "LLM_REFUSED"),
    ({"choices": [{"finish_reason": "stop", "message": {"content": None}}]}, "LLM_INVALID_OUTPUT"),
    ({"choices": [{"finish_reason": "stop", "message": None}]}, "LLM_INVALID_OUTPUT"),
])
def test_incomplete_refused_or_malformed_response_is_error(body, code):
    provider = CompatibleLLMProvider("https://llm.example.test/v1", "model",
        transport=httpx.MockTransport(lambda req: httpx.Response(200, json=body)))
    with pytest.raises(AppError) as error:
        asyncio.run(provider.generate(request()))
    assert error.value.error.code == code


def test_timeout_and_connect_failure_are_distinct():
    for exception, code in [(httpx.ReadTimeout("secret"), "LLM_TIMEOUT"), (httpx.ConnectError("secret"), "LLM_UNAVAILABLE")]:
        def handler(req):
            raise exception
        provider = CompatibleLLMProvider("https://llm.example.test/v1", "model", transport=httpx.MockTransport(handler))
        with pytest.raises(AppError) as error:
            asyncio.run(provider.generate(request()))
        assert error.value.error.code == code


def test_factory_has_no_implicit_mock_fallback(tmp_path):
    assert isinstance(create_provider(Settings(tmp_path)), UnconfiguredLLMProvider)
    assert isinstance(create_provider(Settings(tmp_path, llm_base_url="https://llm.example.test/v1", llm_model="chosen-model")), CompatibleLLMProvider)


def test_output_schema_requires_all_properties_including_nullable_fields():
    def inspect(node):
        if isinstance(node, dict):
            if node.get("type") == "object":
                assert node.get("additionalProperties") is False
                assert set(node["required"]) == set(node["properties"])
            for value in node.values():
                inspect(value)
        elif isinstance(node, list):
            for value in node:
                inspect(value)
    inspect(ParsedIntent.model_json_schema())


@pytest.mark.parametrize('enabled', [None, False, True])
def test_thinking_extension_is_explicit_per_request(enabled):
    captured = []
    def handler(req):
        captured.append(json.loads(req.content))
        return httpx.Response(200, json={'choices': [{'finish_reason': 'stop', 'message': {'content': json.dumps(intent_payload())}}]})
    provider = CompatibleLLMProvider('https://llm.example.test/v1', 'chosen-model', transport=httpx.MockTransport(handler))
    data = request().model_copy(update={'enable_thinking': enabled})
    asyncio.run(provider.generate(data))
    if enabled is None:
        assert 'enable_thinking' not in captured[0]
    else:
        assert captured[0]['enable_thinking'] is enabled
    assert captured[0]['response_format']['type'] == 'json_schema'


@pytest.mark.parametrize('value,expected', [('', None), ('false', False), ('true', True), ('0', False), ('1', True)])
def test_intent_thinking_environment_is_optional(monkeypatch, value, expected):
    monkeypatch.setenv('INSIGHTFLOW_INTENT_ENABLE_THINKING', value)
    assert Settings.from_env().intent_enable_thinking is expected


def test_invalid_thinking_environment_does_not_echo_value(monkeypatch):
    monkeypatch.setenv('INSIGHTFLOW_INTENT_ENABLE_THINKING', 'private-config-value')
    with pytest.raises(ValueError) as caught:
        Settings.from_env()
    assert 'private-config-value' not in str(caught.value)
