import json
from contextlib import closing

from app.domain.analysis_report import AnalysisReport
from app.domain.errors import AppError
from .database import Database


class ReportRepository:
    def __init__(self, database: Database):
        self.database = database
        with closing(database.connect()) as conn, conn:
            conn.execute("CREATE TABLE IF NOT EXISTS analysis_reports (id TEXT PRIMARY KEY, report TEXT NOT NULL, audit TEXT NOT NULL)")
            conn.execute("CREATE TABLE IF NOT EXISTS report_generations (execution_id TEXT PRIMARY KEY, session_id TEXT NOT NULL, status TEXT NOT NULL, record TEXT NOT NULL)")

    def save(self, report: AnalysisReport, audit: dict):
        # Immutable IDs: no update endpoint, no overwrite of earlier reports.
        with closing(self.database.connect()) as conn, conn:
            conn.execute("INSERT INTO analysis_reports VALUES (?, ?, ?)",
                (report.report_id, report.model_dump_json(), json.dumps(audit, ensure_ascii=False, allow_nan=False)))

    def get(self, report_id: str) -> AnalysisReport:
        with closing(self.database.connect()) as conn:
            row = conn.execute("SELECT report FROM analysis_reports WHERE id=?", (report_id,)).fetchone()
        if row is None:
            raise AppError("REPORT_NOT_FOUND", "报告不存在。", 404)
        return AnalysisReport.model_validate_json(row["report"])

    def generation(self, execution_id: str):
        from app.domain.models import ReportGeneration
        with closing(self.database.connect()) as conn:
            row = conn.execute("SELECT record FROM report_generations WHERE execution_id=?", (execution_id,)).fetchone()
        return ReportGeneration.model_validate_json(row['record']) if row else None

    def queue(self, execution_id: str, session_id: str, expected_attempt: int | None = None):
        from app.domain.models import ReportGeneration
        with closing(self.database.connect()) as conn, conn:
            conn.execute('BEGIN IMMEDIATE')
            row = conn.execute('SELECT record FROM report_generations WHERE execution_id=?', (execution_id,)).fetchone()
            previous = ReportGeneration.model_validate_json(row['record']) if row else None
            if previous:
                if expected_attempt is None or previous.status in {'completed', 'unavailable'}:
                    return previous, False
                if previous.status != 'failed' or previous.attempt != expected_attempt:
                    raise AppError('STALE_REPORT_ATTEMPT', '报告状态已更新，请刷新后重试。')
            elif expected_attempt is not None:
                raise AppError('STALE_REPORT_ATTEMPT', '报告生成记录不存在，请刷新后重试。')
            record = ReportGeneration(execution_id=execution_id, session_id=session_id,
                status='queued', attempt=previous.attempt + 1 if previous else 1)
            self._write_generation(conn, record)
            return record, True

    def start(self, execution_id: str, attempt: int):
        from app.domain.models import ReportGeneration, now
        with closing(self.database.connect()) as conn, conn:
            conn.execute('BEGIN IMMEDIATE')
            row = conn.execute('SELECT record FROM report_generations WHERE execution_id=?', (execution_id,)).fetchone()
            record = ReportGeneration.model_validate_json(row['record']) if row else None
            if record is None or record.attempt != attempt or record.status != 'queued':
                return None
            record.status, record.started_at = 'generating', now()
            self._write_generation(conn, record)
            return record

    def finish(self, execution_id: str, attempt: int, report=None, audit=None, error=None):
        from app.domain.models import ReportGeneration, now
        with closing(self.database.connect()) as conn, conn:
            conn.execute('BEGIN IMMEDIATE')
            row = conn.execute('SELECT record FROM report_generations WHERE execution_id=?', (execution_id,)).fetchone()
            record = ReportGeneration.model_validate_json(row['record']) if row else None
            if not record or record.attempt != attempt or record.status not in {'queued', 'generating'}:
                return False
            if report:
                conn.execute('INSERT INTO analysis_reports VALUES (?, ?, ?)',
                    (report.report_id, report.model_dump_json(), json.dumps(audit, ensure_ascii=False, allow_nan=False)))
                record.report_id = report.report_id
                record.status = 'unavailable' if report.report_status == 'unavailable' else 'completed'
            else:
                record.status, record.error = 'failed', error
            record.finished_at = now()
            self._write_generation(conn, record)
        return True

    def _write_generation(self, conn, record):
        from app.domain.models import SessionState, now
        row = conn.execute('SELECT state FROM sessions WHERE id=?', (record.session_id,)).fetchone()
        if row is None:
            raise AppError('SESSION_NOT_FOUND', '会话不存在。', 404)
        state = SessionState.model_validate_json(row['state'])
        state.report_generations = [r for r in state.report_generations if r.execution_id != record.execution_id] + [record]
        state.revision += 1
        state.updated_at = now()
        conn.execute('UPDATE sessions SET state=?, updated_at=? WHERE id=?',
            (state.model_dump_json(), state.updated_at, state.id))
        conn.execute('INSERT OR REPLACE INTO report_generations VALUES (?, ?, ?, ?)',
            (record.execution_id, record.session_id, record.status, record.model_dump_json()))

    def recover_interrupted(self):
        from app.domain.models import ReportGeneration, WorkflowError, now
        with closing(self.database.connect()) as conn, conn:
            conn.execute('BEGIN IMMEDIATE')
            rows = conn.execute("SELECT record FROM report_generations WHERE status IN ('queued','generating')").fetchall()
            for row in rows:
                record = ReportGeneration.model_validate_json(row['record'])
                record.status, record.finished_at = 'failed', now()
                record.error = WorkflowError(code='REPORT_PROCESS_INTERRUPTED', message='报告生成被服务重启中断，可基于已保存的计算结果重试。', retryable=True)
                self._write_generation(conn, record)

    def owner(self, report_id):
        with closing(self.database.connect()) as conn:
            row = conn.execute('SELECT audit FROM analysis_reports WHERE id=?', (report_id,)).fetchone()
        return json.loads(row['audit']).get('session_id') if row else None
