"""Sidecar presentation contracts; no changes to plans or approval snapshots."""
from typing import Any, Literal
from pydantic import Field
from .analysis_plan import PlanModel


class ConstraintProof(PlanModel):
    source: str
    raw_text: str
    status: Literal['verified', 'unmapped', 'mismatch', 'ambiguous']
    category: str
    message: str
    field_ids: list[str] = Field(default_factory=list)
    matches: list[dict[str, Any]] = Field(default_factory=list)


class ConstraintAudit(PlanModel):
    audit_version: Literal['2.0'] = '2.0'
    binding: dict[str, Any]
    digest: str
    all_verified: bool
    items: list[ConstraintProof]


class ReviewIssue(PlanModel):
    code: str
    message: str
    next_step: str


class ReviewCondition(PlanModel):
    label: str
    text: str
    verification: str
    source: str


class ReviewDirection(PlanModel):
    task_id: str
    title: str
    question: str
    importance: str
    reason: str
    readiness: str
    executable: bool
    details: list[str]
    gaps: list[str]
    can_remove: bool


class ReviewPresentation(PlanModel):
    session_id: str
    revision: int
    plan_id: str
    plan_version: int
    goal: str
    coverage: str
    conditions: list[ReviewCondition]
    directions: list[ReviewDirection]
    issues: list[ReviewIssue]
    warnings: list[dict[str, str]]
    can_approve: bool
    can_execute: bool
    audit: ConstraintAudit
    technical_details: dict[str, Any]
