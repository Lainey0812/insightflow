"""Internal selection contract. No model-written factual or explanatory prose."""
from typing import Literal

from pydantic import Field
from app.domain.analysis_plan import Name, PlanModel


class SelectedInsight(PlanModel):
    primary_evidence_id: Name
    evidence_refs: list[Name] = Field(min_length=1, max_length=8)
    finding_type: Literal['highlight', 'difference', 'concentration', 'trend', 'coverage']
    recommendation_id: Name
    limitation_refs: list[Name] = Field(max_length=5)


class InsightSelection(PlanModel):
    insights: list[SelectedInsight] = Field(min_length=1, max_length=8)


def selection_schema(evidence, recommendations, limitation_pool, required_groups):
    schema = InsightSelection.model_json_schema()
    def portable(value):
        if isinstance(value, dict):
            if value.get('pattern') == r'\S':
                value['pattern'] = r'[\s\S]*\S[\s\S]*'
            for child in value.values():
                portable(child)
        elif isinstance(value, list):
            for child in value:
                portable(child)
    portable(schema)
    properties = schema['$defs']['SelectedInsight']['properties']
    ids = [e.evidence_id for e in evidence]
    properties['primary_evidence_id']['enum'] = ids
    properties['evidence_refs']['items']['enum'] = ids
    properties['recommendation_id']['enum'] = ['none', *recommendations]
    properties['limitation_refs']['items']['enum'] = list(limitation_pool)
    schema['properties']['insights']['minItems'] = max(1, len(required_groups))
    return schema
