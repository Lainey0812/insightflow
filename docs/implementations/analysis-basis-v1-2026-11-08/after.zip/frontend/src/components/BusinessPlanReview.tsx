import { useEffect, useState } from 'react';
import { ArrowRight, CheckCircle2, ClipboardList, LoaderCircle, ShieldCheck, Trash2 } from 'lucide-react';
import { api } from '../api/client';
import type { AnalysisBasis, PlanVersion, ReviewPresentation, Session } from '../types/contracts';

const basisFunctions: Record<string,string> = {count:'计数',distinct_count:'去重计数',sum:'合计',avg:'均值',median:'中位数',min:'最小值',max:'最大值'};

interface Props {
  plan: PlanVersion; session: Session; busy: boolean;
  onRemove: (id: string) => void; onConfirm: (warnings?: string[]) => void; onBasisSaved?: (next: Session) => void; onRestart?: () => void;
}

export function BusinessPlanReview({plan, session, busy, onRemove, onConfirm, onBasisSaved, onRestart}: Props) {
  const [view, setView] = useState<ReviewPresentation | null>(null);
  const [acknowledged, setAcknowledged] = useState<string[]>([]);
  const [grain, setGrain] = useState<AnalysisBasis['row_grain']>('unknown');
  const [entityField, setEntityField] = useState('');
  const [basisSaving, setBasisSaving] = useState(false);
  const [basisError, setBasisError] = useState('');
  const [error, setError] = useState('');
  const [reload, setReload] = useState(0);
  const [history, setHistory] = useState<unknown>(null);
  const [historyError, setHistoryError] = useState('');
  useEffect(() => {
    let alive = true;
    setView(null); setError(''); setHistory(null); setAcknowledged([]);
    api.review(session.id).then(next => {
      if (!alive) return;
      if (next.session_id !== session.id || next.plan_id !== plan.plan_id || next.plan_version !== plan.plan_version || next.revision !== session.revision)
        setError('方案已更新，请刷新会话后审核最新内容。');
      else {setView(next);setGrain(next.analysis_basis?.row_grain ?? 'unknown');setEntityField(next.analysis_basis?.entity_field_id ?? '');}
    }).catch(() => {if (alive) setError('暂时无法核对当前方案的审批资格。请重新加载；在核对完成前不会开始分析。');});
    return () => {alive = false;};
  }, [session.id, session.revision, plan.plan_id, plan.plan_version, reload]);
  const current = plan.plan_version === session.current_plan_version;
  const basisEditable = current && ['AWAITING_APPROVAL','APPROVED'].includes(session.status);
  const eligible = !!view && current && (view.can_approve || view.can_execute);
  const ready = eligible && view!.warnings.every(w => acknowledged.includes(w.id) || view!.can_execute);
  const completed = session.review_status === 'completed';
  const buttonLabel = completed ? '分析已完成' : session.review_status === 'execution_failed' ? '分析未完成，请查看结果' : view?.can_execute ? '开始已确认的分析' : '确认并开始分析';
  return <section className="plan-card business-review" aria-label={`分析方案 第${plan.plan_version}版`}>
    <header className="review-heading"><span className="review-symbol"><ClipboardList size={21}/></span><div><h3>请确认分析方案</h3><p>第 {plan.plan_version} 版 · 确认前不会计算</p></div><span className="review-state">{completed ? '已完成' : eligible ? '等待你的确认' : '核对分析条件'}</span></header>
    {error && <div className="review-load-error" role="alert"><p>{error}</p><button className="secondary-button" onClick={() => setReload(n => n + 1)}>重新加载方案</button></div>}
    {!view && !error && <p className="review-loading" role="status"><LoaderCircle size={17} className="spin"/>正在核对分析方案与可用条件…</p>}
    {view && <>
      {view.report_capacity && <section className="review-section" aria-label="报告生成容量">
        <p className="review-eyebrow">报告生成安排</p>
        <p role={view.report_capacity.supported ? 'status' : 'alert'}>{view.report_capacity.message}</p>
      </section>}
      <section className="review-section review-goal"><p className="review-eyebrow">01 · 核心分析目标</p><h4>{view.goal}</h4><p className="review-coverage">{view.coverage}</p></section>
      <section className="review-section"><h4>02 · 分析范围与统计口径</h4><p className="review-explanation">需求条件与方案拟用口径分别标明来源；拟用口径不代表你已确认。</p><dl className="review-conditions">{view.conditions.map((condition, i) => <div key={i}><dt>{condition.label}</dt><dd><strong>{condition.text}</strong><span className={condition.verification === '已核对分析步骤' ? 'condition-verified' : condition.source.startsWith('plan.') ? 'condition-proposed' : 'condition-pending'}>{condition.verification === '已核对分析步骤' && <CheckCircle2 size={12}/>} {condition.verification}</span></dd></div>)}</dl></section>
      {view.analysis_basis && <section className="review-section" aria-label="数据粒度与指标定义"><h4>数据粒度与指标定义</h4>
        <p className="review-explanation">下方为实际计算方法。记录含义不明确时保持未确认；不会根据字段名自动认定一行就是一个实体。</p>
        <ul>{view.analysis_basis.metrics.map(metric=><li key={`${metric.task_id}:${metric.step_id}:${metric.alias}`}>
          <strong>{metric.label}（{basisFunctions[metric.function] ?? '已批准计算'}）</strong>：{metric.basis}{metric.unit_status === 'not_declared' && '；单位未登记，不自动进行单位换算'}</li>)}</ul>
        <details className="basis-editor"><summary>需要说明一行代表什么？</summary>
          <label>记录粒度 <select aria-label="记录粒度" value={grain} disabled={busy || basisSaving || !basisEditable} onChange={event=>{setGrain(event.target.value as AnalysisBasis['row_grain']);setEntityField('');}}>
            <option value="unknown">暂未确认业务含义</option><option value="record">每行一条记录</option><option value="detail">每行一条明细，同一实体可能多行</option><option value="entity">每行一个实体，需唯一标识核验</option>
          </select></label>
          {grain === 'entity' && <label>实体标识 <select aria-label="实体标识" value={entityField} disabled={busy || basisSaving || !basisEditable} onChange={event=>setEntityField(event.target.value)}><option value="">请选择非空且唯一的标识</option>{view.analysis_basis.entity_field_options.map(field=><option key={field.field_id} value={field.field_id} disabled={!field.unique_non_null}>{field.label}{!field.unique_non_null && '（含缺失或重复）'}</option>)}</select></label>}
          <p>声明只描述上传数据，不改变中间分组结果的含义。保存会生成新计划版本并要求重新审批。计算字段、函数保持不变；如需改为去重或调整指标，请重新提出明确需求。</p>
          {basisError && <p role="alert">{basisError}</p>}
          <button className="secondary-button" disabled={busy || basisSaving || !basisEditable || !onBasisSaved || (grain === 'entity' && !entityField)} onClick={async()=>{
            setBasisSaving(true);setBasisError('');try {const next=await api.saveAnalysisBasis(session,grain,grain === 'entity' ? entityField : null);onBasisSaved?.(next);} catch(error) {setBasisError(error instanceof Error ? error.message : '口径保存失败，请刷新当前方案。');} finally {setBasisSaving(false);}
          }}>{basisSaving ? '正在保存口径…' : '保存粒度声明并重新审核'}</button>
        </details>
      </section>}
      <section className="review-section"><h4>03 · 分析方向</h4><p className="review-explanation">每个方向回答一个业务问题，不包含尚未计算的结论。</p><ol className="review-directions">{view.directions.map((direction, i) => <li key={direction.task_id}>
        <div className="direction-top"><span className="direction-index">{String(i + 1).padStart(2, '0')}</span><span className={`direction-importance ${direction.importance === '核心分析' ? 'core' : ''}`}>{direction.importance}</span><span className={`direction-ready ${direction.executable ? '' : 'blocked'}`}>{direction.readiness}</span></div>
        <h5>{direction.title}</h5><p className="direction-question">{direction.question}</p><p className="direction-reason">为什么分析：{direction.reason}</p>
        <ul className="direction-method">{direction.details.map((line, j) => <li key={j}>{line}</li>)}</ul>
        {direction.gaps.map((gap, j) => <p className="direction-gap" key={j}>{gap}</p>)}
        {current && <button className="direction-remove" onClick={() => onRemove(direction.task_id)} disabled={busy || basisSaving || !direction.can_remove} aria-label={`删除${direction.title}`}><Trash2 size={13}/>移除此方向{direction.importance === '核心分析' && <span>（会重新检查核心目标）</span>}</button>}
      </li>)}</ol>{!view.directions.length && <p className="review-issue">当前没有分析方向，请重新提出需求。</p>}</section>
      <section className="review-section"><h4>04 · 待确认事项</h4>{view.issues.length ? <ul className="review-issues">{view.issues.map((issue, i) => <li key={i}><strong>{issue.message}</strong><p>{issue.next_step}</p></li>)}</ul> : <p className="review-no-issues"><ShieldCheck size={17}/>当前没有阻止审批的待解决事项。</p>}
        {view.warnings.map(warning => <label className="review-warning" key={warning.id}><input type="checkbox" checked={view.can_execute || acknowledged.includes(warning.id)} disabled={busy || view.can_execute || completed} onChange={event => setAcknowledged(values => event.target.checked ? [...values, warning.id] : values.filter(id => id !== warning.id))}/><span>{warning.label}</span></label>)}
      </section>
    </>}
    <footer className="review-actions"><div><h4>05 · 确认与操作</h4><p><ShieldCheck size={14}/>按当前方案和文件版本开始</p><small>分析后可查看真实计算结果与报告</small></div><button className="primary-button" disabled={busy || basisSaving || !ready} onClick={() => {if (ready) onConfirm(acknowledged);}}>{buttonLabel}<ArrowRight size={15}/></button></footer>
    <div className="review-restart"><p>如需修改范围或口径，请重新提出需求；当前方案会保留。</p>{onRestart && <button className="secondary-button" disabled={busy} onClick={onRestart}>重新提出需求</button>}</div>
    <details className="review-technical"><summary>技术详情</summary><p>此处保留原始计划、字段引用、约束来源与逐步核验结果。</p><pre>{JSON.stringify(view?.technical_details ?? {record: plan}, null, 2)}</pre>
      <button className="secondary-button" disabled={busy} onClick={async () => {setHistoryError('');try {const versions = await api.versions(session.id);const approvals = await api.approvals(session.id);const proofs = await api.constraintAudits(session.id);setHistory({versions, approvals, constraint_audits: proofs});} catch {setHistoryError('版本记录暂时无法加载，请稍后重试。');}}}>版本与审批记录</button>
      {historyError && <p role="alert">{historyError}</p>}{history !== null && <pre>{JSON.stringify(history, null, 2)}</pre>}
    </details>
  </section>;
}
