import { useEffect, useState } from 'react';
import { ArrowRight, CheckCircle2, ClipboardList, LoaderCircle, ShieldCheck, Trash2 } from 'lucide-react';
import { api } from '../api/client';
import type { PlanVersion, ReviewPresentation, Session } from '../types/contracts';

interface Props {
  plan: PlanVersion; session: Session; busy: boolean;
  onRemove: (id: string) => void; onConfirm: (warnings?: string[]) => void; onRestart?: () => void;
}

export function BusinessPlanReview({plan, session, busy, onRemove, onConfirm, onRestart}: Props) {
  const [view, setView] = useState<ReviewPresentation | null>(null);
  const [acknowledged, setAcknowledged] = useState<string[]>([]);
  const [error, setError] = useState('');
  const [reload, setReload] = useState(0);
  const [history, setHistory] = useState<unknown>(null);
  const [historyError, setHistoryError] = useState('');
  useEffect(() => {
    let alive = true;
    setView(null); setError(''); setHistory(null); setAcknowledged([]);
    api.review(session.id).then(next => {
      if (!alive) return;
      if (next.session_id !== session.id || next.plan_id !== plan.plan_id || next.plan_version !== plan.plan_version || next.revision !== session.revision)
        setError('方案已更新，请刷新会话后审核最新内容。');
      else setView(next);
    }).catch(() => {if (alive) setError('暂时无法核对当前方案的审批资格。请重新加载；在核对完成前不会开始分析。');});
    return () => {alive = false;};
  }, [session.id, session.revision, plan.plan_id, plan.plan_version, reload]);
  const current = plan.plan_version === session.current_plan_version;
  const eligible = !!view && current && (view.can_approve || view.can_execute);
  const ready = eligible && view!.warnings.every(w => acknowledged.includes(w.id) || view!.can_execute);
  const completed = session.review_status === 'completed';
  const buttonLabel = completed ? '分析已完成' : session.review_status === 'execution_failed' ? '分析未完成，请查看结果' : view?.can_execute ? '开始已确认的分析' : '确认并开始分析';
  return <section className="plan-card business-review" aria-label={`分析方案 第${plan.plan_version}版`}>
    <header className="review-heading"><span className="review-symbol"><ClipboardList size={21}/></span><div><h3>请确认分析方案</h3><p>第 {plan.plan_version} 版 · 确认前不会计算</p></div><span className="review-state">{completed ? '已完成' : eligible ? '等待你的确认' : '核对分析条件'}</span></header>
    {error && <div className="review-load-error" role="alert"><p>{error}</p><button className="secondary-button" onClick={() => setReload(n => n + 1)}>重新加载方案</button></div>}
    {!view && !error && <p className="review-loading" role="status"><LoaderCircle size={17} className="spin"/>正在核对分析方案与可用条件…</p>}
    {view && <>
      {view.report_capacity && <section className="review-section" aria-label="报告生成容量">
        <p className="review-eyebrow">报告生成安排</p>
        <p role={view.report_capacity.supported ? 'status' : 'alert'}>{view.report_capacity.message}</p>
      </section>}
      <section className="review-section review-goal"><p className="review-eyebrow">01 · 核心分析目标</p><h4>{view.goal}</h4><p className="review-coverage">{view.coverage}</p></section>
      <section className="review-section"><h4>02 · 分析范围与统计口径</h4><p className="review-explanation">需求条件与方案拟用口径分别标明来源；拟用口径不代表你已确认。</p><dl className="review-conditions">{view.conditions.map((condition, i) => <div key={i}><dt>{condition.label}</dt><dd><strong>{condition.text}</strong><span className={condition.verification === '已核对分析步骤' ? 'condition-verified' : condition.source.startsWith('plan.') ? 'condition-proposed' : 'condition-pending'}>{condition.verification === '已核对分析步骤' && <CheckCircle2 size={12}/>} {condition.verification}</span></dd></div>)}</dl></section>
      <section className="review-section"><h4>03 · 分析方向</h4><p className="review-explanation">每个方向回答一个业务问题，不包含尚未计算的结论。</p><ol className="review-directions">{view.directions.map((direction, i) => <li key={direction.task_id}>
        <div className="direction-top"><span className="direction-index">{String(i + 1).padStart(2, '0')}</span><span className={`direction-importance ${direction.importance === '核心分析' ? 'core' : ''}`}>{direction.importance}</span><span className={`direction-ready ${direction.executable ? '' : 'blocked'}`}>{direction.readiness}</span></div>
        <h5>{direction.title}</h5><p className="direction-question">{direction.question}</p><p className="direction-reason">为什么分析：{direction.reason}</p>
        <ul className="direction-method">{direction.details.map((line, j) => <li key={j}>{line}</li>)}</ul>
        {direction.gaps.map((gap, j) => <p className="direction-gap" key={j}>{gap}</p>)}
        {current && <button className="direction-remove" onClick={() => onRemove(direction.task_id)} disabled={busy || !direction.can_remove} aria-label={`删除${direction.title}`}><Trash2 size={13}/>移除此方向{direction.importance === '核心分析' && <span>（会重新检查核心目标）</span>}</button>}
      </li>)}</ol>{!view.directions.length && <p className="review-issue">当前没有分析方向，请重新提出需求。</p>}</section>
      <section className="review-section"><h4>04 · 待确认事项</h4>{view.issues.length ? <ul className="review-issues">{view.issues.map((issue, i) => <li key={i}><strong>{issue.message}</strong><p>{issue.next_step}</p></li>)}</ul> : <p className="review-no-issues"><ShieldCheck size={17}/>当前没有阻止审批的待解决事项。</p>}
        {view.warnings.map(warning => <label className="review-warning" key={warning.id}><input type="checkbox" checked={view.can_execute || acknowledged.includes(warning.id)} disabled={busy || view.can_execute || completed} onChange={event => setAcknowledged(values => event.target.checked ? [...values, warning.id] : values.filter(id => id !== warning.id))}/><span>{warning.label}</span></label>)}
      </section>
    </>}
    <footer className="review-actions"><div><h4>05 · 确认与操作</h4><p><ShieldCheck size={14}/>按当前方案和文件版本开始</p><small>分析后可查看真实计算结果与报告</small></div><button className="primary-button" disabled={busy || !ready} onClick={() => {if (ready) onConfirm(acknowledged);}}>{buttonLabel}<ArrowRight size={15}/></button></footer>
    <div className="review-restart"><p>如需修改范围或口径，请重新提出需求；当前方案会保留。</p>{onRestart && <button className="secondary-button" disabled={busy} onClick={onRestart}>重新提出需求</button>}</div>
    <details className="review-technical"><summary>技术详情</summary><p>此处保留原始计划、字段引用、约束来源与逐步核验结果。</p><pre>{JSON.stringify(view?.technical_details ?? {record: plan}, null, 2)}</pre>
      <button className="secondary-button" disabled={busy} onClick={async () => {setHistoryError('');try {const versions = await api.versions(session.id);const approvals = await api.approvals(session.id);const proofs = await api.constraintAudits(session.id);setHistory({versions, approvals, constraint_audits: proofs});} catch {setHistoryError('版本记录暂时无法加载，请稍后重试。');}}}>版本与审批记录</button>
      {historyError && <p role="alert">{historyError}</p>}{history !== null && <pre>{JSON.stringify(history, null, 2)}</pre>}
    </details>
  </section>;
}
