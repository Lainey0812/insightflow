// Frozen real C2 response; modified copies are isolated component fault fixtures, never browser/server data.
import { fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { expect, it, vi } from 'vitest';
import { AdminRoutes } from '../app/routes';
import { isWorkflow, workflowApi } from '../api/workflows';
import type { WorkflowView } from '../types/workflows';
import fixture from './fixtures/workflow-c2.json';
const source=()=>structuredClone(fixture) as unknown as WorkflowView;
function page(items:unknown[]=[source()]) {return {schema_version:'workflow-observability-page-v1',items,total:items.length,limit:20,offset:0,sort:'created_at DESC, workflow_id ASC',notice:'readonly'};}
function view(path:string) {render(<MemoryRouter initialEntries={[path]}><AdminRoutes /></MemoryRouter>);}
function response(value:unknown,status=200) {return new Response(JSON.stringify(value),{status,headers:{'content-type':'application/json'}});}

it('uses the frozen real C2 sample for list-to-detail and fourteen actual nodes',async()=>{
  const fetcher=vi.fn(async(input:RequestInfo|URL,_init?:RequestInit)=>response(String(input).includes('/workflow-observability/'+fixture.workflow_id)?source():page()));vi.stubGlobal('fetch',fetcher);
  view('/traces/workflows');
  fireEvent.click(await screen.findByRole('link',{name:fixture.workflow_id}));
  expect(await screen.findByRole('heading',{name:'生命周期时间线'})).toBeVisible();
  expect(screen.getAllByTestId('workflow-node')).toHaveLength(14);
  expect(screen.getByText(/14 个实际 Span/)).toHaveTextContent('3 条已采集 LLM 调用');
  expect(screen.getByText(fixture.root_run_id)).toBeVisible();
  expect(screen.getByText('分析已完成')).toBeVisible();
  expect(screen.queryByRole('button',{name:/批准|开始分析|恢复执行|重试分析/})).not.toBeInTheDocument();
  const node=screen.getAllByTestId('workflow-node').find(n=>n.textContent?.includes('analysis_engine'))!;
  fireEvent.click(within(node).getByText('分析执行'));
  expect(within(node).getAllByText(fixture.trace.executions[0].execution_id).length).toBeGreaterThan(0);
  expect(fetcher.mock.calls.every(([,init])=>!init||init.method===undefined||init.method==='GET')).toBe(true);
});

it('submits exact filters in the URL and paginates without a control API',async()=>{
  const fetcher=vi.fn(async(_input:RequestInfo|URL)=>response({...page(),total:21}));vi.stubGlobal('fetch',fetcher);
  view('/traces/workflows');await screen.findByText('21 条真实 Workflow');
  fireEvent.change(screen.getByLabelText('Workflow ID'),{target:{value:fixture.workflow_id}});
  fireEvent.change(screen.getByLabelText('业务生命周期'),{target:{value:'succeeded'}});
  fireEvent.click(screen.getByRole('button',{name:'查询'}));
  await waitFor(()=>expect(String(fetcher.mock.calls.at(-1)?.[0])).toContain('workflow_id='+fixture.workflow_id));
  await waitFor(()=>expect(screen.getByRole('button',{name:'下一页'})).toBeEnabled());
  fireEvent.click(screen.getByRole('button',{name:'下一页'}));
  await waitFor(()=>expect(String(fetcher.mock.calls.at(-1)?.[0])).toContain('offset=20'));
});

it('keeps delivered business status when Trace is unavailable without fabricating nodes',async()=>{
  const data=source();data.trace!.nodes=[];data.trace!.events=[];data.trace!.llm_calls=[];
  data.collection.status='incomplete';data.collection.findings=[{category:'executed_trace_missing',code:'EXECUTION_SPAN_NOT_COLLECTED',evidence_refs:[fixture.trace.executions[0].execution_id]}];
  vi.stubGlobal('fetch',vi.fn(async()=>response(data)));view('/traces/workflows/'+fixture.workflow_id);
  expect(await screen.findByText('分析已完成')).toBeVisible();
  expect(screen.getByText('已执行，Trace 缺失')).toBeVisible();
  expect(screen.queryAllByTestId('workflow-node')).toHaveLength(0);
  expect(screen.getByText('暂无可读取的实际节点')).toBeVisible();
});

it('distinguishes explicit skip, incomplete observation, inconsistency and unknown',async()=>{
  const data=source();data.collection.findings=[
    {category:'not_executed',code:'NO_EVIDENCE',evidence_refs:['unit_skip_event']},
    {category:'observation_incomplete',code:'RECORDED_COLLECTION_GAP',evidence_refs:[]},
    {category:'inconsistent',code:'WORKFLOW_TRACE_IDENTITY_MISMATCH',evidence_refs:[]},
    {category:'unknown',code:'ROOT_NOT_COLLECTED',evidence_refs:[]}];data.collection.status='incomplete';
  vi.stubGlobal('fetch',vi.fn(async()=>response(data)));view('/traces/workflows/'+fixture.workflow_id);
  expect(await screen.findByText('明确未执行')).toBeVisible();
  for(const text of ['观测不完整','业务与关联不一致','尚无法判断'])expect(screen.getByText(text)).toBeVisible();
  expect(screen.getAllByTestId('workflow-node')).toHaveLength(14);
});

it('renders retry metadata and events without an executable retry button',async()=>{
  const data=source();data.trace!.llm_calls[0].retry_index=1;data.trace!.llm_calls[0].retry_of_call_id='call_unit_previous';
  vi.stubGlobal('fetch',vi.fn(async()=>response(data)));view('/traces/workflows/'+fixture.workflow_id);
  const nodes=await screen.findAllByTestId('workflow-node');const node=nodes.find(n=>n.textContent?.includes('intent_parser'))!;
  fireEvent.click(within(node).getByText('需求理解'));
  expect(within(node).getByText(/请求重试 #1/)).toBeVisible();
  expect(within(node).getByText(/call_unit_previous/)).toBeVisible();
  expect(within(node).getByText('span.started')).toBeVisible();
});
it('supports empty filtered results',async()=>{
  vi.stubGlobal('fetch',vi.fn(async()=>response(page([]))));view('/traces/workflows?session_id=missing');
  expect(await screen.findByRole('heading',{name:'没有匹配的 Workflow'})).toBeVisible();
});
it('shows authorization failure rather than simulated records',async()=>{
  vi.stubGlobal('fetch',vi.fn(async()=>response({},403)));view('/traces/workflows');
  expect(await screen.findByRole('heading',{name:'需要管理员只读访问'})).toBeVisible();
});
it('rejects wrong ownership in API payloads',async()=>{
  expect(isWorkflow(source())).toBe(true);const wrong=source();wrong.trace!.root_run_id='other';expect(isWorkflow(wrong)).toBe(false);
  vi.stubGlobal('fetch',vi.fn(async()=>response(wrong)));
  await expect(workflowApi.get(fixture.workflow_id)).rejects.toThrow('Workflow 详情结构或归属不正确');
});

it('does not invent historical content for an unknown Workflow ID',async()=>{
  vi.stubGlobal('fetch',vi.fn(async()=>response({},404)));view('/traces/workflows/wf_not_registered');
  expect(await screen.findByRole('heading',{name:'Workflow 不存在或未登记'})).toBeVisible();
  expect(screen.queryAllByTestId('workflow-node')).toHaveLength(0);
});
