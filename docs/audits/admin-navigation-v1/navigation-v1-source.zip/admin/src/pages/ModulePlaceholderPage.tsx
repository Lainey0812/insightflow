import { Link } from 'react-router-dom';
import { EmptyState } from '../components/EmptyState';
import { Workflow } from 'lucide-react';
import type { NavigationPage } from '../app/navigation';

export function ModulePlaceholderPage({ page }: { page: NavigationPage }) {
  const detail = page.key === 'trace-detail';
  return <>
    <div className="page-heading"><span className="eyebrow">INSIGHTFLOW ADMIN</span><h1>{page.label}</h1><p>{page.later ? '后期功能' : detail ? '选择真实运行查看详情' : '后台模块入口'}</p></div>
    <EmptyState statusLabel={detail ? '请选择真实运行' : page.later ? '后期功能' : undefined} icon={Workflow} title={detail ? '尚未选择运行' : page.later ? '后期开放' : '尚未接入'} description={page.description || '本模块尚未接入管理接口。'} note={detail ? '从真实运行列表进入，保留完整的运行 ID 和来源。' : '当前仅提供导航与页面框架，不展示模拟业务数据或不可用的操作。'} />
    {detail && <p><Link className="primary-button" to="/traces">打开 Run Explorer</Link></p>}
  </>;
}
