import { fireEvent, render, screen, within } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { expect, it, vi } from 'vitest';
import { AdminRoutes } from '../app/routes';
import { currentNavigation } from '../app/navigation';

function view(path: string) { return render(<MemoryRouter initialEntries={[path]}><AdminRoutes /></MemoryRouter>); }
it('shows the requested groups and expands navigation without losing the active page', () => {
  view('/workflows/planning');
  const nav = screen.getByRole('navigation', { name: '主导航' });
  expect(within(nav).getByRole('link', { name: '运行总览' })).toHaveAttribute('href', '/dashboard');
  for (const label of ['工作流管理', 'Prompt 管理', '版本与发布', '运行追踪', '评测中心', 'Bad Case', '系统管理']) {
    expect(within(nav).getByRole('button', { name: label })).toBeVisible();
  }
  expect(within(nav).getByRole('link', { name: 'Planning' })).toHaveAttribute('aria-current', 'page');
  const workflow = within(nav).getByRole('button', { name: '工作流管理' });
  expect(workflow).toHaveAttribute('aria-expanded', 'true');
  fireEvent.click(workflow);
  expect(workflow).toHaveAttribute('aria-expanded', 'false');
  fireEvent.click(within(nav).getByRole('button', { name: 'Prompt 管理' }));
  expect(within(nav).getByRole('link', { name: 'Playground（后期）' })).toHaveAttribute('href', '/prompts/playground');
});
it('directly loads a future page without simulated data or model/API calls', () => {
  const fetcher = vi.fn(); vi.stubGlobal('fetch', fetcher);
  view('/prompts/playground');
  expect(screen.getByRole('heading', { name: 'Playground' })).toBeVisible();
  expect(screen.getByRole('heading', { name: '后期开放' })).toBeVisible();
  expect(within(screen.getByRole('main')).queryByRole('button', { name: '运行模型' })).not.toBeInTheDocument();
  expect(fetcher).not.toHaveBeenCalled();
});
it('does not treat the Trace Detail landing route as a fabricated run ID', () => {
  const fetcher = vi.fn(); vi.stubGlobal('fetch', fetcher);
  view('/traces/detail');
  expect(screen.getByRole('heading', { name: '尚未选择运行' })).toBeVisible();
  expect(screen.getByRole('link', { name: '打开 Run Explorer' })).toHaveAttribute('href', '/traces');
  expect(fetcher).not.toHaveBeenCalled();
});
it('maps existing comparison and dynamic detail URLs to their intended navigation groups', () => {
  expect(currentNavigation('/traces/compare').group?.label).toBe('版本与发布');
  expect(currentNavigation('/traces/compare').page?.label).toBe('版本对比');
  expect(currentNavigation('/traces/run_existing').page?.label).toBe('Trace Detail');
  expect(currentNavigation('/traces/run_existing').group?.label).toBe('运行追踪');
  expect(currentNavigation('/does-not-exist').page).toBeUndefined();
});
it('keeps permission integration for new placeholder routes', () => {
  render(<MemoryRouter initialEntries={['/evaluations/datasets']}><AdminRoutes resolveAccess={() => 'denied'} /></MemoryRouter>);
  expect(screen.getByRole('alert')).toHaveTextContent('权限检查未允许访问');
  expect(screen.queryByRole('heading', { name: '尚未接入' })).not.toBeInTheDocument();
});
