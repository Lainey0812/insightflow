import { Workflow } from 'lucide-react';
import { EmptyState } from '../components/EmptyState';

export function TracesPage() {
  return <><div className="page-heading"><span className="eyebrow">WORKFLOW TRACES</span><h1>Workflow Trace</h1><p>未来从一次分析出发，追溯各阶段的输入、输出与问题。</p></div>
    <EmptyState icon={Workflow} title="暂无可查看的 Trace" description="Trace 查询与采集尚未接入，当前无法展示工作流执行记录。" note="本阶段没有新增埋点，也没有生成演示 Trace 或模拟运行记录。" /></>;
}
