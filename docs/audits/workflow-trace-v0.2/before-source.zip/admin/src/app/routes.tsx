import { Navigate, Route, Routes } from 'react-router-dom';
import { AdminLayout } from '../layouts/AdminLayout';
import { DashboardPage } from '../pages/DashboardPage';
import { TracesPage } from '../pages/TracesPage';
import { VersionsPage } from '../pages/VersionsPage';
import { SettingsPage } from '../pages/SettingsPage';
import { NotFoundPage } from '../pages/NotFoundPage';
import { AccessBoundary } from '../auth/AccessBoundary';
import type { AccessResolver } from '../auth/AccessBoundary';
import { navigation } from './navigation';

const pages = {
  '/dashboard': DashboardPage,
  '/traces': TracesPage,
  '/versions': VersionsPage,
  '/settings': SettingsPage,
};

export function AdminRoutes({ resolveAccess }: { resolveAccess?: AccessResolver }) {
  return <Routes><Route element={<AdminLayout />}>
    <Route index element={<Navigate to="/dashboard" replace />} />
    {navigation.map(item => {
      const Page = pages[item.path];
      return <Route key={item.path} path={item.path} element={<AccessBoundary permission={item.permission} resolve={resolveAccess}><Page /></AccessBoundary>} />;
    })}
    <Route path="*" element={<NotFoundPage />} />
  </Route></Routes>;
}
