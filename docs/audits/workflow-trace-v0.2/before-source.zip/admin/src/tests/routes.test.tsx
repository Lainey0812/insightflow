import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { describe, expect, it, vi } from 'vitest';
import { AdminRoutes } from '../app/routes';
import { ErrorBoundary } from '../components/ErrorBoundary';

describe('independent admin routes', () => {
  it.each([
    ['/dashboard', '运行概览', '暂无运行数据'],
    ['/traces', 'Workflow Trace', '暂无可查看的 Trace'],
    ['/versions', '版本对比', '尚未接入版本数据'],
    ['/settings', '系统设置', '本地配置'],
  ])('directly renders %s without API calls or fabricated monitoring data', (path, title, content) => {
    const fetcher = vi.fn(); vi.stubGlobal('fetch', fetcher);
    render(<MemoryRouter initialEntries={[path]}><AdminRoutes /></MemoryRouter>);
    expect(screen.getByRole('heading', { level: 1, name: title })).toBeVisible();
    expect(screen.getByRole('heading', { level: 2, name: content })).toBeVisible();
    expect(screen.getByText(/身份认证与监控接口尚未接入/)).toBeVisible();
    expect(screen.queryByText(/100%|超级管理员|登录成功/)).not.toBeInTheDocument();
    expect(fetcher).not.toHaveBeenCalled();
  });
  it('redirects the root to dashboard and handles unknown URLs', () => {
    const { unmount } = render(<MemoryRouter initialEntries={['/']}><AdminRoutes /></MemoryRouter>);
    expect(screen.getByRole('heading', { level: 1, name: '运行概览' })).toBeVisible(); unmount();
    render(<MemoryRouter initialEntries={['/not-a-page']}><AdminRoutes /></MemoryRouter>);
    expect(screen.getByRole('heading', { level: 1, name: '页面不存在' })).toBeVisible();
    expect(screen.getByRole('link', { name: '返回运行概览' })).toHaveAttribute('href', '/dashboard');
  });
  it('keeps the future permission integration point separate from fake login', () => {
    render(<MemoryRouter initialEntries={['/traces']}><AdminRoutes resolveAccess={() => 'denied'} /></MemoryRouter>);
    expect(screen.getByRole('alert')).toHaveTextContent('权限检查未允许访问');
    expect(screen.queryByText('暂无可查看的 Trace')).not.toBeInTheDocument();
  });
  it('shows a controlled fallback for rendering errors', () => {
    vi.spyOn(console, 'error').mockImplementation(() => undefined);
    function Broken(): never { throw new Error('internal diagnostic details'); }
    render(<ErrorBoundary><Broken /></ErrorBoundary>);
    expect(screen.getByRole('heading', { name: '管理台暂时无法显示' })).toBeVisible();
    expect(screen.queryByText('internal diagnostic details')).not.toBeInTheDocument();
  });
});
