"""Read-only, independently authorized metadata API. Never serves raw snapshots."""
import secrets
from typing import Literal
from fastapi import APIRouter, Depends, Header, Query
from app.domain.errors import AppError
from pydantic import BaseModel
from app.domain.tracing import TraceRun, TraceSpan, TraceEvent

class RunPage(BaseModel):
    items: list[TraceRun]
    total: int
    limit: int
    offset: int
    coverage_notice: str
    collector_degraded: bool
    retention: dict

class RunDetail(BaseModel):
    run: TraceRun
    business_source: dict
    coverage_notice: str
    collector_degraded: bool

class SpanPage(BaseModel):
    items: list[TraceSpan]

class EventPage(BaseModel):
    items: list[TraceEvent]
    limit: int
    offset: int

NOTICE='Trace is best-effort; missing observations do not imply no business runs or failures.'

def create_admin_router(traces, reports, token):
    def authorize(x_admin_token: str = Header(default='')):
        if not token:
            raise AppError('ADMIN_NOT_CONFIGURED','管理员只读接口尚未配置。',503)
        if not secrets.compare_digest(x_admin_token.encode(),token.encode()):
            raise AppError('ADMIN_ACCESS_DENIED','缺少有效的管理员只读凭证。',403)
        if traces.repository is None:
            raise AppError('TRACE_UNAVAILABLE','追踪存储暂不可用，业务结果请通过原接口查询。',503)

    router=APIRouter(prefix='/admin',tags=['Admin Trace V0.1'],dependencies=[Depends(authorize)])
    def read(action):
        try:return action()
        except AppError:raise
        except Exception:raise AppError('TRACE_UNAVAILABLE','追踪查询暂不可用。',503) from None
    def find_run(run_id):
        run=read(lambda:traces.repository.get(run_id))
        if not run:raise AppError('TRACE_RUN_NOT_FOUND','追踪记录不存在。',404)
        return run
    def find_span(span_id):
        span=read(lambda:traces.repository.span(span_id))
        if not span:raise AppError('TRACE_SPAN_NOT_FOUND','追踪阶段不存在。',404)
        return span

    @router.get('/runs',response_model=RunPage)
    def runs(limit:int=Query(50,ge=1,le=100),offset:int=Query(0,ge=0,le=1000000),
             status:Literal['queued','running','complete','partial','unavailable','failed','interrupted']|None=None):
        items,total=read(lambda:traces.repository.runs(limit,offset,status))
        return {'items':items,'total':total,'limit':limit,'offset':offset,'coverage_notice':NOTICE,
            'collector_degraded':traces.degraded,
            'retention':{'metadata':'keep_until_explicit_policy_change','raw_content':'not_collected',
                'max_events_per_run':256,'max_event_payload_bytes':8192}}

    @router.get('/runs/{run_id}',response_model=RunDetail)
    def run(run_id:str):
        record=find_run(run_id)
        source={'available':False,'latest_attempt':None,'status':None,'same_attempt':False,'report_status':None,'goal_coverage':None}
        try:
            generation=reports.generation(record.execution_id)
            if generation:
                source.update(available=True,latest_attempt=generation.attempt,status=generation.status,
                              same_attempt=generation.attempt==record.attempt)
            if record.report_id:
                report=reports.get(record.report_id)
                source.update(report_status=report.report_status,goal_coverage=report.goal_coverage)
        except Exception:pass
        return {'run':record,'business_source':source,'coverage_notice':NOTICE,'collector_degraded':traces.degraded}

    @router.get('/runs/{run_id}/spans',response_model=SpanPage)
    def spans(run_id:str):
        find_run(run_id)
        return {'items':read(lambda:traces.repository.spans(run_id))}

    @router.get('/spans/{span_id}/events',response_model=EventPage)
    def events(span_id:str,limit:int=Query(100,ge=1,le=100),offset:int=Query(0,ge=0,le=1000000)):
        find_span(span_id)
        return {'items':read(lambda:traces.repository.events(span_id,limit,offset)),'limit':limit,'offset':offset}
    return router
