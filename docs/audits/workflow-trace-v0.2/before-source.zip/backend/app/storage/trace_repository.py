"""SQLite sidecar: observations only, no copies of analysis results or approvals."""
from contextlib import closing
from pathlib import Path
import sqlite3
from app.domain.tracing import TraceRun, TraceSpan, TraceEvent
from app.domain.models import now

class TraceRepository:
    def __init__(self, directory: Path):
        directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.path = directory / 'trace.sqlite3'
        with closing(self.connect()) as conn, conn:
            conn.execute('PRAGMA journal_mode=WAL')
            conn.executescript('''
                CREATE TABLE IF NOT EXISTS trace_runs (
                    id TEXT PRIMARY KEY, execution_id TEXT NOT NULL, attempt INTEGER NOT NULL,
                    queued_at TEXT NOT NULL, status TEXT NOT NULL, record TEXT NOT NULL,
                    UNIQUE(execution_id, attempt));
                CREATE TABLE IF NOT EXISTS trace_spans (
                    id TEXT PRIMARY KEY, run_id TEXT NOT NULL REFERENCES trace_runs(id), record TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS spans_run ON trace_spans(run_id);
                CREATE TABLE IF NOT EXISTS trace_events (
                    id TEXT PRIMARY KEY, run_id TEXT NOT NULL REFERENCES trace_runs(id),
                    span_id TEXT REFERENCES trace_spans(id), sequence INTEGER NOT NULL, record TEXT NOT NULL,
                    UNIQUE(run_id, sequence));
                CREATE INDEX IF NOT EXISTS events_span ON trace_events(span_id, sequence);
            ''')
        self.path.chmod(0o600)

    def connect(self):
        conn = sqlite3.connect(self.path, timeout=0.025)
        conn.row_factory = sqlite3.Row
        conn.execute('PRAGMA foreign_keys=ON')
        return conn

    def attempt(self, execution_id, attempt):
        with closing(self.connect()) as conn:
            row = conn.execute('SELECT record FROM trace_runs WHERE execution_id=? AND attempt=?', (execution_id,attempt)).fetchone()
        return TraceRun.model_validate_json(row['record']) if row else None

    def create(self, run):
        with closing(self.connect()) as conn, conn:
            conn.execute('INSERT OR IGNORE INTO trace_runs VALUES (?, ?, ?, ?, ?, ?)',
                (run.run_id,run.execution_id,run.attempt,run.queued_at,run.status,run.model_dump_json()))
        return self.attempt(run.execution_id,run.attempt)

    def update_run(self, run):
        with closing(self.connect()) as conn, conn:
            row=conn.execute('SELECT record FROM trace_runs WHERE id=?',(run.run_id,)).fetchone()
            if row is None: raise ValueError('Trace run missing')
            previous=TraceRun.model_validate_json(row['record'])
            if previous.manifest != run.manifest: raise ValueError('Manifest is immutable')
            if previous.status not in {'queued','running'}: return
            allowed={'queued':{'queued','running','interrupted'},
                     'running':{'running','complete','partial','failed','unavailable','interrupted'}}
            if run.status not in allowed[previous.status]: raise ValueError('Invalid observation transition')
            if any(getattr(run,key)!=getattr(previous,key) for key in
                   ('session_id','execution_id','attempt','retry_of_run_id','owner_instance','queued_at')):
                raise ValueError('Run identity is immutable')
            conn.execute('UPDATE trace_runs SET status=?,record=? WHERE id=?',(run.status,run.model_dump_json(),run.run_id))

    def save_span(self, span):
        with closing(self.connect()) as conn, conn:
            if span.parent_span_id:
                parent=conn.execute('SELECT run_id FROM trace_spans WHERE id=?',(span.parent_span_id,)).fetchone()
                if not parent or parent['run_id']!=span.run_id: raise ValueError('Cross-run parent')
            previous=conn.execute('SELECT run_id,record FROM trace_spans WHERE id=?',(span.span_id,)).fetchone()
            if previous and (previous['run_id'] != span.run_id or TraceSpan.model_validate_json(previous['record']).status != 'running'):
                raise ValueError('Span is immutable after completion')
            conn.execute('INSERT INTO trace_spans VALUES (?,?,?) ON CONFLICT(id) DO UPDATE SET record=excluded.record',
                         (span.span_id,span.run_id,span.model_dump_json()))

    def event(self, event):
        with closing(self.connect()) as conn, conn:
            if event.span_id:
                row=conn.execute('SELECT run_id FROM trace_spans WHERE id=?',(event.span_id,)).fetchone()
                if not row or row['run_id']!=event.run_id: raise ValueError('Cross-run event')
            existing=conn.execute('SELECT record FROM trace_events WHERE id=?',(event.event_id,)).fetchone()
            if existing:
                if existing['record'] != event.model_dump_json(): raise ValueError('Conflicting event identity')
                return
            conn.execute('INSERT INTO trace_events VALUES (?,?,?,?,?)',
                (event.event_id,event.run_id,event.span_id,event.sequence,event.model_dump_json()))

    def get(self, run_id):
        with closing(self.connect()) as conn:
            row=conn.execute('SELECT record FROM trace_runs WHERE id=?',(run_id,)).fetchone()
        return TraceRun.model_validate_json(row['record']) if row else None

    def span(self, span_id):
        with closing(self.connect()) as conn:
            row=conn.execute('SELECT record FROM trace_spans WHERE id=?',(span_id,)).fetchone()
        return TraceSpan.model_validate_json(row['record']) if row else None

    def runs(self, limit=50, offset=0, status=None):
        where,args=(' WHERE status=?',[status]) if status else ('',[])
        with closing(self.connect()) as conn:
            total=conn.execute('SELECT COUNT(*) FROM trace_runs'+where,args).fetchone()[0]
            rows=conn.execute('SELECT record FROM trace_runs'+where+' ORDER BY queued_at DESC,id DESC LIMIT ? OFFSET ?',(*args,limit,offset)).fetchall()
        return [TraceRun.model_validate_json(row['record']) for row in rows],total

    def spans(self, run_id):
        with closing(self.connect()) as conn:
            rows=conn.execute('SELECT record FROM trace_spans WHERE run_id=? ORDER BY rowid',(run_id,)).fetchall()
        return [TraceSpan.model_validate_json(r['record']) for r in rows]

    def events(self, span_id, limit=100, offset=0):
        with closing(self.connect()) as conn:
            rows=conn.execute('SELECT record FROM trace_events WHERE span_id=? ORDER BY sequence LIMIT ? OFFSET ?',
                             (span_id,limit,offset)).fetchall()
        return [TraceEvent.model_validate_json(r['record']) for r in rows]

    def recover(self):
        # Same single-process deployment boundary as the business recovery code.
        with closing(self.connect()) as conn, conn:
            for row in conn.execute("SELECT record FROM trace_runs WHERE status IN ('queued','running')").fetchall():
                run=TraceRun.model_validate_json(row['record'])
                run.status,run.error_code,run.integrity='interrupted','TRACE_PROCESS_INTERRUPTED','incomplete'
                run.recovered_at=now()
                run.duration_ms=None
                conn.execute('UPDATE trace_runs SET status=?,record=? WHERE id=?',(run.status,run.model_dump_json(),run.run_id))
                for spanrow in conn.execute('SELECT record FROM trace_spans WHERE run_id=?',(run.run_id,)).fetchall():
                    span=TraceSpan.model_validate_json(spanrow['record'])
                    if span.status=='running':
                        span.status,span.error_code='interrupted','TRACE_PROCESS_INTERRUPTED'
                        span.recovered_at=run.recovered_at
                        span.duration_ms=None
                        conn.execute('UPDATE trace_spans SET record=? WHERE id=?',(span.model_dump_json(),span.span_id))
