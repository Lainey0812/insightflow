import { ApiError, createAdminClient } from './client';
import type { EventPage, RunDetail, RunPage, TraceSpan } from '../types/traces';

const client = createAdminClient();
function invalid(): never { throw new ApiError('INVALID_RESPONSE', '追踪接口返回结构不正确。'); }
export const traceApi = {
  async runs(query: string, signal?: AbortSignal): Promise<RunPage> {
    const value = await client.get<RunPage>('runs?' + query, { signal, cache: 'no-store' });
    if (!value || !Array.isArray(value.items) || !Number.isInteger(value.total) || value.total < 0 ||
        value.items.some(run => !run || typeof run.run_id !== 'string' || typeof run.status !== 'string')) invalid();
    return value;
  },
  async run(id: string, signal?: AbortSignal): Promise<RunDetail> {
    const value = await client.get<RunDetail>('runs/' + encodeURIComponent(id), { signal, cache: 'no-store' });
    if (!value?.run || value.run.run_id !== id || typeof value.run.status !== 'string') invalid();
    return value;
  },
  async spans(id: string, signal?: AbortSignal): Promise<TraceSpan[]> {
    const value = await client.get<{ items: TraceSpan[] }>('runs/' + encodeURIComponent(id) + '/spans', { signal, cache: 'no-store' });
    if (!value || !Array.isArray(value.items) || value.items.some(s => !s || s.run_id !== id || typeof s.span_id !== 'string' || typeof s.name !== 'string')) invalid();
    return value.items;
  },
  async events(id: string, offset: number, signal?: AbortSignal): Promise<EventPage> {
    const value = await client.get<EventPage>(`spans/${encodeURIComponent(id)}/events?limit=100&offset=${offset}`, { signal, cache: 'no-store' });
    if (!value || !Array.isArray(value.items) || value.items.some(e => !e || e.span_id !== id || typeof e.event_id !== 'string')) invalid();
    return value;
  },
  grant(token: string) { return client.request('access', { method: 'POST', headers: { 'X-Admin-Token': token }, cache: 'no-store' }); },
  revoke() { return client.request('access', { method: 'DELETE', headers: { 'X-Admin-Request': '1' }, cache: 'no-store' }); },
};
