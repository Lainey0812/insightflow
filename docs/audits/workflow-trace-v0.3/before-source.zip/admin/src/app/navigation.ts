import { LayoutDashboard, Workflow, GitCompareArrows, Settings2 } from 'lucide-react';
import type { AdminPermission } from '../auth/AccessBoundary';

export const navigation = [
  { path: '/dashboard', label: '运行概览', icon: LayoutDashboard, permission: 'dashboard:view' },
  { path: '/traces', label: 'Workflow Trace', icon: Workflow, permission: 'traces:view' },
  { path: '/versions', label: '版本对比', icon: GitCompareArrows, permission: 'versions:view' },
  { path: '/settings', label: '系统设置', icon: Settings2, permission: 'settings:view' },
] as const satisfies ReadonlyArray<{ path: string; label: string; icon: typeof LayoutDashboard; permission: AdminPermission }>;
