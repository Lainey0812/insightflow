import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { RefreshCw, ArrowUpRight, Workflow } from 'lucide-react';
import { traceApi } from '../api/traces';
import type { RunPage } from '../types/traces';
import { TraceError, RevokeAccess } from '../features/traces/AccessPanel';
import { CoverageNotice, StatusBadge } from '../features/traces/TraceShared';
import { durationText, metadata, nodeLabels, statusLabels, timeText, valueText } from '../features/traces/presentation';
import { EmptyState } from '../components/EmptyState';

function positive(value: string | null, fallback: number, min: number, max: number) {
  const parsed = value === null ? fallback : Number(value);
  return Number.isInteger(parsed) && parsed >= min && parsed <= max ? parsed : fallback;
}
export function TracesPage() {
  const [params, setParams] = useSearchParams();
  const [page, setPage] = useState<RunPage | null>(null), [error, setError] = useState<unknown>(null);
  const [loading, setLoading] = useState(true), [refresh, setRefresh] = useState(0), [formError, setFormError] = useState('');
  const limit = positive(params.get('limit'), 20, 1, 100), offset = positive(params.get('offset'), 0, 0, 1000000);
  const request = new URLSearchParams({ limit: String(limit), offset: String(offset) });
  for (const key of ['status', 'from_time', 'to_time', 'node', 'version']) if (params.get(key)) request.set(key, params.get(key)!);
  const query = request.toString();
  const reload = () => setRefresh(value => value + 1);
  useEffect(() => {
    const controller = new AbortController(); setLoading(true); setError(null); setPage(null);
    traceApi.runs(query, controller.signal).then(value => { if (!controller.signal.aborted) setPage(value); })
      .catch(cause => { if (!controller.signal.aborted) setError(cause); })
      .finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => controller.abort();
  }, [query, refresh]);
  function filter(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); const data = new FormData(event.currentTarget); const next = new URLSearchParams({ limit: String(limit) });
    setFormError('');
    const start = String(data.get('from_time') || ''), end = String(data.get('to_time') || '');
    if (start && end && new Date(start) > new Date(end)) { setFormError('开始时间不能晚于结束时间。'); return; }
    for (const key of ['status', 'node', 'version']) { const value = String(data.get(key) || '').trim(); if (value) next.set(key, value); }
    for (const [key, value] of [['from_time', start], ['to_time', end]]) if (value) {
      const date = new Date(value); if (!Number.isFinite(date.getTime())) { setFormError('时间格式不正确。'); return; } next.set(key, date.toISOString());
    }
    setParams(next);
  }
  const localInput = (key: string) => {
    const value = params.get(key); if (!value || !Number.isFinite(Date.parse(value))) return '';
    const date = new Date(value); return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}T${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}:${String(date.getSeconds()).padStart(2, '0')}`;
  };
  function move(nextOffset: number) { const next = new URLSearchParams(params); next.set('offset', String(nextOffset)); next.set('limit', String(limit)); setParams(next); }
  return <>
    <div className="trace-heading"><div><span className="eyebrow">WORKFLOW TRACES</span><h1>Workflow Trace</h1><p>从真实报告运行记录定位阶段、版本与校验问题。</p></div><div className="trace-actions"><button className="secondary-button" onClick={reload} disabled={loading}><RefreshCw size={14} />手动刷新</button>{page && <RevokeAccess done={reload} />}</div></div>
    <form key={params.toString()} className="trace-filters trace-card" onSubmit={filter} aria-label="运行筛选">
      <label>状态<select name="status" defaultValue={params.get('status') || ''}><option value="">全部状态</option>{['queued', 'running', 'complete', 'partial', 'unavailable', 'failed', 'interrupted'].map(status => <option key={status} value={status}>{statusLabels[status]}</option>)}</select></label>
      <label>排队时间从（本地）<input name="from_time" type="datetime-local" step="1" defaultValue={localInput('from_time')} /></label>
      <label>排队时间至（本地）<input name="to_time" type="datetime-local" step="1" defaultValue={localInput('to_time')} /></label>
      <label>包含节点<input aria-label="包含节点" name="node" list="trace-nodes" placeholder="全部节点" defaultValue={params.get('node') || ''} maxLength={128} /><datalist id="trace-nodes">{Object.entries(nodeLabels).map(([name, label]) => <option key={name} value={name}>{label}</option>)}</datalist></label>
      <label>版本精确匹配<input name="version" placeholder="Prompt / 生成 / Schema / 校验版本" defaultValue={params.get('version') || ''} maxLength={160} /></label>
      <div className="filter-actions"><button className="primary-button" type="submit">应用筛选</button><button className="secondary-button" type="button" onClick={() => { setFormError(''); setParams({ limit: String(limit) }); }}>重置</button></div>
      {formError && <p role="alert">{formError}</p>}
    </form>
    <CoverageNotice degraded={page?.collector_degraded} />
    {loading ? <div className="trace-message" role="status">正在读取后端运行记录…</div> : error ? <TraceError error={error} retry={reload} /> : page && <>
      {page.items.length === 0 ? <EmptyState icon={Workflow} title={offset ? '当前页没有记录' : '没有匹配的运行记录'} description="接口已返回空结果。可调整筛选条件或等待新的报告尝试；未生成演示数据。" note="历史报告没有埋点时不会自动出现 Trace。" /> : <div className="trace-card trace-table-wrap"><table className="trace-table"><caption className="visually-hidden">真实运行列表</caption><thead><tr><th>运行</th><th>状态</th><th>排队时间</th><th>整体耗时</th><th>版本</th><th>尝试</th><th>操作</th></tr></thead><tbody>{page.items.map(run => <tr key={run.run_id}>
        <td><code className="run-id">{run.run_id}</code><small>执行：{valueText(run.execution_id)}</small>{run.integrity === 'incomplete' && <span className="integrity-tag">追踪不完整</span>}</td><td><StatusBadge status={run.status} /></td><td>{timeText(run.queued_at)}</td><td>{durationText(run.duration_ms)}</td><td><span>{valueText(metadata(run.manifest?.versions).prompt_version)}</span><small>{valueText(metadata(run.manifest?.versions).schema_version)}</small></td><td>{typeof run.attempt === 'number' ? `第 ${run.attempt} 次` : '未采集'}</td><td><Link className="trace-link" to={'/traces/' + encodeURIComponent(run.run_id)}>查看详情 <ArrowUpRight size={13} /></Link></td>
      </tr>)}</tbody></table></div>}
      <div className="trace-pagination"><span>匹配 {page.total} 条 · 第 {Math.floor(offset / limit) + 1} 页</span><label>每页<select aria-label="每页记录数" value={limit} onChange={e => { const next = new URLSearchParams(params); next.set('limit', e.target.value); next.delete('offset'); setParams(next); }}>{Array.from(new Set([limit, 10, 20, 50, 100])).sort((a, b) => a - b).map(value => <option key={value} value={value}>{value}</option>)}</select></label><button className="secondary-button" disabled={offset === 0} onClick={() => move(Math.max(0, offset - limit))}>上一页</button><button className="secondary-button" disabled={offset + limit >= page.total} onClick={() => move(offset + limit)}>下一页</button></div>
    </>}
  </>;
}
