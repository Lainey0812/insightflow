import { GitCompareArrows } from 'lucide-react';
import { EmptyState } from '../components/EmptyState';

export function VersionsPage() {
  return <><div className="page-heading"><span className="eyebrow">VERSION COMPARISON</span><h1>版本对比</h1><p>为后续对比需求、实现版本与评测结果预留入口。</p></div>
    <EmptyState icon={GitCompareArrows} title="尚未接入版本数据" description="版本查询 API 尚未实现。已有版本档案继续保存在项目本地，本页面暂不读取或比较。" note="本阶段不新增版本管理后端，也不展示虚构的版本列表或评测分数。" /></>;
}
