import { NavLink, Outlet, useLocation } from 'react-router-dom';
import { ChevronRight, Layers3, PanelLeftClose, PanelLeftOpen } from 'lucide-react';
import { useState } from 'react';
import { navigation } from '../app/navigation';

export function AdminLayout() {
  const [expanded, setExpanded] = useState(true);
  const { pathname } = useLocation();
  const title = navigation.find(item => item.path === pathname || (item.path === '/traces' && pathname.startsWith('/traces/')))?.label ?? '页面不存在';
  return <div className={`admin-shell ${expanded ? '' : 'sidebar-collapsed'}`}>
    <a className="skip-link" href="#main-content">跳转到内容</a>
    <aside className="sidebar" aria-label="管理台侧边栏">
      <NavLink className="brand" to="/dashboard"><span className="brand-symbol"><Layers3 size={23} /></span><span>InsightFlow<small>ADMIN CONSOLE</small></span></NavLink>
      <div className="nav-section-label">测试管理</div>
      <nav aria-label="主导航">{navigation.map(({ path, label, icon: Icon }) => <NavLink key={path} to={path} aria-label={label} className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`} end={path !== '/traces'}><Icon size={19} strokeWidth={1.7} /><span>{label}</span><ChevronRight className="nav-arrow" size={14} /></NavLink>)}</nav>
      <div className="sidebar-footer"><span className="local-marker">LOCAL / V0.2</span><p>只读诊断</p><small>Trace 已接入；其他模块仍为占位。</small></div>
    </aside>
    <div className="workspace">
      <header className="topbar"><div className="topbar-start"><button className="icon-button" aria-label={expanded ? '收起侧边栏' : '展开侧边栏'} aria-expanded={expanded} onClick={() => setExpanded(!expanded)}>{expanded ? <PanelLeftClose size={19} /> : <PanelLeftOpen size={19} />}</button><span className="breadcrumb">管理控制台 <ChevronRight size={14} /><strong>{title}</strong></span></div><span className="preview-badge">V0.2 · Trace 诊断</span></header>
      <main id="main-content" className="main-content" tabIndex={-1}>
        <div className="framework-notice"><span className="neutral-dot" />Trace 使用服务端只读访问；其他模块仍为工程占位。</div>
        <Outlet />
        <footer className="page-footer"><span>InsightFlow Admin Console</span><span>仅展示已采集记录 · 缺失信息不推断</span></footer>
      </main>
    </div>
  </div>;
}
