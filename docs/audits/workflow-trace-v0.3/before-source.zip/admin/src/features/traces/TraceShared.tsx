import type { Metadata, RunManifest } from '../../types/traces';
import { metadata, statusLabels, valueText } from './presentation';

export function StatusBadge({ status }: { status: string }) {
  const known = Object.hasOwn(statusLabels, status);
  return <span className={`status-badge ${known ? 'status-' + status : 'status-unknown'}`}>{statusLabels[status] || '未知状态'}<small>{status}</small></span>;
}
export function KeyValues({ source, fields }: { source: Metadata; fields: Record<string, string> }) {
  return <dl className="trace-keyvalues">{Object.entries(fields).map(([key, label]) => <div key={key}><dt>{label}</dt><dd>{valueText(source[key])}</dd></div>)}</dl>;
}
export function CoverageNotice({ degraded, incomplete }: { degraded?: boolean; incomplete?: boolean }) {
  return <div className={`trace-notice ${degraded || incomplete ? 'trace-warning' : ''}`} role="note">
    {degraded || incomplete ? '检测到追踪缺口或采集器降级。' : ''} 当前仅覆盖报告生成尝试；记录缺失不代表业务没有运行或没有失败。</div>;
}
const hashes = ['services/analysis_report.py', 'workflow/reporting.py', 'reporting/evidence.py', 'reporting/fact_validation.py', 'reporting/claims.py', 'reporting/prompt.py', 'reporting/selection.py', 'reporting/contracts.py', 'reporting/visualization.py', 'domain/analysis_report.py', 'domain/tracing.py', 'observability/recorder.py'];
export function ManifestView({ manifest }: { manifest?: RunManifest }) {
  return <details className="trace-card manifest-panel"><summary>RunManifest · 本次运行的版本与关联</summary>
    {!manifest && <p>历史记录未采集 RunManifest。</p>}
    <KeyValues source={metadata(manifest?.bindings)} fields={{ session_id: '会话 ID', execution_id: '执行 ID', approval_id: '审批 ID', dataset_id: '数据集 ID', dataset_version: '数据集版本', plan_id: '计划 ID', plan_version: '计划版本' }} />
    <KeyValues source={metadata(manifest?.versions)} fields={{ prompt_version: 'Prompt 版本', generation_version: '生成策略', schema_version: '报告 Schema', validation_version: 'Validator 版本', registry_version: 'Registry 版本' }} />
    <KeyValues source={metadata(manifest?.model_config_snapshot)} fields={{ provider: '配置 Provider', model: '配置模型', timeout_seconds: '超时（秒）', enable_thinking: '思考配置', temperature: 'temperature', top_p: 'top_p', usage: 'Token 用量' }} />
    <details><summary>实现文件指纹</summary><KeyValues source={metadata(manifest?.source_sha256)} fields={Object.fromEntries(hashes.map(key => [key, key]))} /></details>
    <p className="muted">只展示已知的元信息字段。未采集原始数据或候选文本快照。</p>
  </details>;
}
