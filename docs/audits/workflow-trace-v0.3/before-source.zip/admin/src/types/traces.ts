export type RunStatus = 'queued' | 'running' | 'complete' | 'partial' | 'unavailable' | 'failed' | 'interrupted';
export type Metadata = Record<string, unknown>;
export interface RunManifest {
  schema_version?: string; bindings?: Metadata; versions?: Metadata;
  model_config_snapshot?: Metadata; source_sha256?: Record<string, string>; raw_content_retained?: boolean;
}
export interface TraceRun {
  run_id: string; kind?: string; session_id?: string; execution_id?: string; attempt?: number;
  retry_of_run_id?: string | null; status: RunStatus; queued_at?: string; started_at?: string | null;
  finished_at?: string | null; recovered_at?: string | null; duration_ms?: number | null;
  report_id?: string | null; error_code?: string | null; integrity?: string; manifest?: RunManifest;
}
export interface TraceSpan {
  span_id: string; run_id: string; parent_span_id?: string | null; name: string; status: string;
  started_at?: string; finished_at?: string | null; recovered_at?: string | null;
  duration_ms?: number | null; error_code?: string | null; attributes?: Metadata;
}
export interface TraceEvent {
  event_id: string; run_id: string; span_id?: string | null; sequence: number;
  event_type: string; recorded_at?: string; payload?: Metadata;
}
export interface RunPage {
  items: TraceRun[]; total: number; limit: number; offset: number;
  collector_degraded?: boolean; coverage_notice?: string;
}
export interface RunDetail {
  run: TraceRun; business_source?: Metadata; collector_degraded?: boolean; coverage_notice?: string;
}
export interface EventPage { items: TraceEvent[]; limit: number; offset: number }
