"""Observation contracts. Business records remain the source of analysis truth."""
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field

class TraceModel(BaseModel):
    model_config = ConfigDict(extra='forbid')

class RunManifest(TraceModel):
    schema_version: Literal['workflow-trace-v0.1'] = 'workflow-trace-v0.1'
    bindings: dict = Field(default_factory=dict)
    versions: dict = Field(default_factory=dict)
    model_config_snapshot: dict = Field(default_factory=dict)
    source_sha256: dict[str, str] = Field(default_factory=dict)
    raw_content_retained: Literal[False] = False

class TraceRun(TraceModel):
    run_id: str
    kind: Literal['report_generation'] = 'report_generation'
    session_id: str
    execution_id: str
    attempt: int = Field(ge=1)
    retry_of_run_id: str | None = None
    owner_instance: str
    status: Literal['queued','running','complete','partial','unavailable','failed','interrupted']
    queued_at: str
    started_at: str | None = None
    finished_at: str | None = None
    recovered_at: str | None = None
    duration_ms: float | None = Field(default=None, ge=0)
    report_id: str | None = None
    error_code: str | None = None
    integrity: Literal['observed','incomplete'] = 'observed'
    manifest: RunManifest

class TraceSpan(TraceModel):
    span_id: str
    run_id: str
    parent_span_id: str | None = None
    name: str
    status: Literal['running','complete','partial','failed','skipped','interrupted']
    started_at: str
    finished_at: str | None = None
    recovered_at: str | None = None
    duration_ms: float | None = Field(default=None, ge=0)
    error_code: str | None = None
    attributes: dict = Field(default_factory=dict)

class TraceEvent(TraceModel):
    event_id: str
    run_id: str
    span_id: str | None = None
    sequence: int = Field(ge=1)
    event_type: str
    recorded_at: str
    payload: dict = Field(default_factory=dict)
