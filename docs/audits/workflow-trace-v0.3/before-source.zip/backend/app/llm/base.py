from typing import Any, Protocol

from pydantic import BaseModel, StrictBool


class LLMRequest(BaseModel):
    purpose: str
    instruction: str
    system_prompt: str = ""
    response_schema: dict[str, Any] | None = None
    enable_thinking: StrictBool | None = None


class LLMResponse(BaseModel):
    text: str
    provider: str
    is_mock: bool
    model: str | None = None


class LLMProvider(Protocol):
    async def generate(self, request: LLMRequest) -> LLMResponse: ...
