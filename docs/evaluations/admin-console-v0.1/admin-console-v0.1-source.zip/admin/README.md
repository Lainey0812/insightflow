# InsightFlow Admin Console V0.1

独立的本地测试管理界面。本阶段只有路由、布局、空状态和接入基础；没有监控采集、真实 Trace、版本查询、评测中心或身份认证。

## 安装与启动

使用 Node.js 22.12+（本轮验证版本 25.5.0）和 npm。与 `frontend/` 各自安装依赖，不使用 workspace。

```sh
cd /Users/lainey/Desktop/vibe-coding/insightflow/admin
npm ci
npm run dev
```

访问 http://127.0.0.1:5174/dashboard。也可直接访问 `/traces`、`/versions`、`/settings`；根路径跳转到 `/dashboard`。未知路径显示 404。

默认仅绑定 127.0.0.1，端口被占用时明确失败，不会自动选择其他端口。退出之前启动的服务后重试，或通过独立配置修改端口。

## 配置

默认值已内置，无需创建 `.env` 即可启动。需要覆盖时，将本目录 `.env.example` 复制为 `.env.local`，修改后重启开发服务；生产构建需重新构建。

| 变量 | 默认值 | 用途 |
| --- | --- | --- |
| `VITE_ADMIN_API_BASE_URL` | `/api/v1/admin` | 客户端 API 命名空间，当前后端尚未实现 |
| `ADMIN_DEV_PORT` | `5174` | 开发端口 |
| `ADMIN_PREVIEW_PORT` | `4174` | 构建产物预览端口 |
| `ADMIN_API_PROXY_TARGET` | `http://127.0.0.1:8000` | 本地开发和预览的 `/api` 代理目标 |

`VITE_` 变量会进入浏览器产物，只放公开配置，禁止放 API Key。Admin 不读取 backend 或 frontend 的 `.env`。页面渲染不会调用尚未实现的 API，也不会将后台业务数据打包进前端。

## 检查与构建

```sh
npm run typecheck
npm test
npm run build
npm run preview
```

构建输出为 `admin/dist/`。预览地址为 http://127.0.0.1:4174/dashboard。Vite 的开发与预览服务支持 SPA 路由回退；未来使用其他静态服务时，须将非资源、非 API 的页面路径回退到 `index.html`，否则直接刷新深层路由可能出现服务器 404。`vite preview` 用于本地验收。

## 目录与接入点

```text
admin/
├── .env.example / .gitignore
├── package.json / package-lock.json
├── index.html / tsconfig.json / vite.config.ts
├── public/favicon.svg
└── src/
    ├── app/             # App、路由和导航元信息
    ├── layouts/         # 侧边栏、顶部导航、内容容器
    ├── pages/           # 四个页面和 404
    ├── components/      # 空状态和渲染错误边界
    ├── api/client.ts    # JSON 请求、错误、取消和超时
    ├── config/env.ts    # 公开配置解析
    ├── auth/            # 未来服务端权限结果的路由挂载点
    ├── tests/           # API 和路由基础测试
    ├── main.tsx
    └── styles.css
```

后续服务模块通过 `createAdminClient()` 发起请求，并在页面明确区分加载、真实空结果和请求失败。当前 `AccessBoundary` 的 `unconfigured` 仅用于本地框架预览，不代表登录成功或身份认证已完成。未来需接入真实身份与服务端授权；前端路由不能替代后端权限校验。

当前统一 API Client 处理 HTTP 错误、网络错误、无效 JSON、超时与取消，不自动重试写入，也不硬编码密钥。响应类型参数是开发契约，未来真实 API 仍应补充对应响应校验。

详细检查、变更与验收记录见 [V0.1 工程说明](../docs/admin-console-v0.1.md)。
